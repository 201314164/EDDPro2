/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuarios;

import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


/**
 * REST Web Service
 *
 * @author gios
 */
@Path("/usuarios")
public class UserResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of UserResource
     */
    public UserResource() {
    }

    /**
     * Retrieves representation of an instance of Usuarios.UserResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<usuario> getJson() {
    AVL temp = ApplicationConfig.usuarios;
    
        List<usuario> resp = temp.recorrer();
        return resp;
        
        
        
    }

    /**
     * POST method for creating an instance of User
     * @param content representation for the new resource
     * @return an HTTP response with content of the created resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public usuario postJson(usuario content) {
        
        
        String niuId = content.getId();
        
        if(ApplicationConfig.usuarios.buscar(niuId)){ //Ya existe
            
            return null;
            
        }else{
            usuario resp = new usuario(content.getId(),content.getPass(),content.getNombre());
            ApplicationConfig.usuarios.insertar(resp);
        
            return resp;
            
        }
        
        
        
        
    }
    
    @Path("/modUsu")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    
    public int modJson(usuario content) {
        
        
        if(ApplicationConfig.usuarios.buscar(content.getId())){
            NodoAVL mod = ApplicationConfig.usuarios.obtener(content.getId());
            mod.setUsuario(content);
            return 1;
            
        }else{
            
            return 0;
            
        }
        
        
    }
    
    @Path("/delUsu")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    
    public int delJson(usuario content) {
        
        
        if(ApplicationConfig.usuarios.buscar(content.getId())){
            ApplicationConfig.usuarios.borrar(content.getId());
            return 1;
            
        }else{
            
            return 0;
            
        }
        
        
    }
    
    @Path("/logUsu/{id}/{pass}")
    @GET
    public int logJson(@PathParam("id") String id, @PathParam("pass") String pass) {
        
        
        
        if(id.equals("admin") && pass.equals("201314164")){
            return 1;
        }else{
            
            if(ApplicationConfig.usuarios.buscar(id)){
                NodoAVL cred = ApplicationConfig.usuarios.obtener(id);
                
                if(id.equals(cred.getUsuario().getId()) && pass.equals(cred.getUsuario().getPass())){
                    return 1;
                    
                }else{
                    return 0;
                }
                
                
            } else{
                return 0;
            }
            
            
            
            
            
        }
        
        
        
    }
    


}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuarios;

import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author gios
 */
public class User {

    private String user;

    /**
     * Creates a new instance of User
     */
    private User(String user) {
        this.user = user;
    }

    /**
     * Get instance of the User
     */
    public static User getInstance(String user) {
        // The user may use some kind of persistence mechanism
        // to store and restore instances of User class.
        return new User(user);
    }

    /**
     * Retrieves representation of an instance of Usuarios.User
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of User
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }

    /**
     * DELETE method for resource User
     */
    @DELETE
    public void delete() {
    }
}

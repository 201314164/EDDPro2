/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuarios;

import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author gios
 */
@Path("/getRaiz")
public class GetUsuarios {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of GetUsuarios
     */
    public GetUsuarios() {
    }

    /**
     * Retrieves representation of an instance of Usuarios.GetUsuarios
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<usuario> getJson() {
        
        AVL temp = ApplicationConfig.usuarios;
        List<usuario> resp = temp.recorrer();
        
        
        
        
        return resp;
        
    }

    /**
     * PUT method for updating or creating an instance of GetUsuarios
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public int putJson(usuario content) {
        
        ApplicationConfig.usuarios.insertar(new usuario(content.getId(),content.getPass(),content.getNombre()));
        return 1;
        
    }
}

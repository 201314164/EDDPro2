function deletCat(){
    httpPost(delCat,getValueForm("deleCatform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Catedratico Eliminado", "Operacion Exitosa");

            


    
        
        
        }else if (result.result =="0"){


            toastr.error("El Catedratico no existe","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
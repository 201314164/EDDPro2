function nuevoCurs(){
    httpPost(niuCur,getValueForm3("niuCurform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Curso Argegado", "Operacion Exitosa");

            

        }else if(result.result == "0"){

        
            toastr.error("Lista de catedraticos vacia ","Hacen Falta Recursos");

        }else if(result.result == "2"){

        
            toastr.error("El codigo ya esta en uso ","Operacion Fallida");
        
        }else if(result.result == "3"){

        
            toastr.error("Existe el curso con codigo distinto ","Operacion Fallida");
        
        
        }else{


            toastr.error("Ocurrio un error ","Operacion Fallida");
            

        }
    });
}
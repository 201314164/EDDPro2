const seledi = document.getElementById('selectEdi');

//const logo = document.createElement('img');
//logo.src = 'logo.png';

//const container = document.createElement('div');
//container.setAttribute('class','container');

//app.appendChild(logo);
//app.appendChild(container);


// se crea una variable de peticion y se le asigna un objeto tipo XMLHttpRequest a ella
var request23 = new XMLHttpRequest();

//Se abre una nueva conexion, usando una peticion GET y la URL del endpoint
request23.open('GET','http://192.168.1.140:9098/proyecto1/getEdi', true);

request23.onload = function (){
 //aqui se accesde al JSON
   var data23 = JSON.parse(this.response);

   
if (request23.status >= 200 && request23.status < 400){

  for ( var i = 0; i < data23.result.length; i++) {
     //const card = document.createElement('td');
     //card.setAttribute('class','card');
     const opt = document.createElement('option');
     opt.setAttribute('value',data23.result[i].nombre);
     opt.textContent = data23.result[i].nombre;
     
    


    
     //const p = document.createElement('p');
     //movie.description = movie.description.substring(0,300);
     //p.textContent = `${movie.description}...`;
     /*<a href="#">
        <button type="button" class="btn btn-cyan btn-sm" data-toggle="modal" data-target="#Modal2">
          Editar
      </button>
      </a>
      <a href="#">
        <button type="button" class="btn btn-danger btn-sm">Eliminar</button>
      </a>  
      <a href="#" data-toggle="tooltip" data-placement="top" title="" data-original-title="Update">
                                                <i class="mdi mdi-check"></i>
                                            </a>
      
      */

     //container.appendChild(card);
 
     seledi.appendChild(opt);
     
     //card.appendChild(p);


   }
} else { 
     
    const opt = document.createElement('option');
     opt.setAttribute('value',"NULL");
     opt.textContent = "Error obteniendo lista";
     seledi.appendChild(opt);

 }
}


//se envia la peticion
request23.send();


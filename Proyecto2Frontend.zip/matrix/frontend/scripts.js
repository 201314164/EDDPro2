const app = document.getElementById('root');

//const logo = document.createElement('img');
//logo.src = 'logo.png';

//const container = document.createElement('div');
//container.setAttribute('class','container');

//app.appendChild(logo);
//app.appendChild(container);


// se crea una variable de peticion y se le asigna un objeto tipo XMLHttpRequest a ella
var request = new XMLHttpRequest();

//Se abre una nueva conexion, usando una peticion GET y la URL del endpoint
request.open('GET','http://192.168.1.140:9098/proyecto1/getEdi', true);

request.onload = function (){
 //aqui se accesde al JSON
   var data = JSON.parse(this.response);

   
if (request.status >= 200 && request.status < 400){

  for ( var i = 0; i < data.result.length; i++) {
     //const card = document.createElement('td');
     //card.setAttribute('class','card');
     const tr = document.createElement('tr');
     const td = document.createElement('td');
     td.setAttribute('id',i);
     td.setAttribute('data-cont',data.result[i].nombre);
     td.textContent = data.result[i].nombre;

    //const container = document.createElement('div');
    const td2 = document.createElement('td');

     const a = document.createElement('a');
     a.setAttribute('href','#');
     a.setAttribute('data-toggle','tooltip');
     a.setAttribute('data-placement','top');
     a.setAttribute('title','');
     a.setAttribute('data-original-title','Editar');

     const di = document.createElement('i');
     di.setAttribute('data-cont',data.result[i].nombre);
     di.setAttribute('class','mdi mdi-settings');
     di.setAttribute('data-toggle', 'modal');
     di.setAttribute('data-target','#Modal23');

     const a2 = document.createElement('a');
     a2.setAttribute('href','#');
     a2.setAttribute('data-toggle','tooltip');
     a2.setAttribute('data-placement','top');
     a2.setAttribute('title','');
     a2.setAttribute('data-original-title','Eliminar');

     const di2 = document.createElement('i');
     di2.setAttribute('data-cont',data.result[i].nombre);
     di2.setAttribute('class','mdi mdi-close');
     di2.setAttribute('data-toggle', 'modal');
     di2.setAttribute('data-target','#Modal24');
     

     //const p = document.createElement('p');
     //movie.description = movie.description.substring(0,300);
     //p.textContent = `${movie.description}...`;
     /*<a href="#">
        <button type="button" class="btn btn-cyan btn-sm" data-toggle="modal" data-target="#Modal2">
          Editar
      </button>
      </a>
      <a href="#">
        <button type="button" class="btn btn-danger btn-sm">Eliminar</button>
      </a>  
      <a href="#" data-toggle="tooltip" data-placement="top" title="" data-original-title="Update">
                                                <i class="mdi mdi-check"></i>
                                            </a>
      
      */

     //container.appendChild(card);
     a.appendChild(di);
     a2.appendChild(di2);
     td2.appendChild(a);
     td2.append(a2);
     tr.appendChild(td);
     tr.appendChild(td2);
     app.appendChild(tr);
     
     //card.appendChild(p);


   }
} else { 
  const tr = document.createElement('tr');
  const td = document.createElement('td');
  td.setAttribute('id',i);
  td.setAttribute('data-cont',data.result[i].nombre);
  td.textContent = "Error cargando lista";
  tr.appendChild(td); 
  app.appendChild(tr);  


 }
}


//se envia la peticion
request.send();


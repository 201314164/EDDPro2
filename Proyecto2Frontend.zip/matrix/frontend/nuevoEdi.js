function nuevoEdif(){
    httpPost(niuEdi,getValueForm("niuEdiform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Edificio Agregado", "Operacion Exitosa");

            


    
        
        
        }else{


            toastr.error("El edificio ya existe","Operacion Fallida");
            

        }
    });
}

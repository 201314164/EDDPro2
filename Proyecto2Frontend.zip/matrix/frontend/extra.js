function Upload() {

    var fileUpload = document.getElementById("fileUpload");

    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt)$/;

    if (regex.test(fileUpload.value.toLowerCase())) {

        
            //-----crea lector
            var reader = new FileReader();

            reader.onload = function (e) {

                var table = document.createElement("table");
                //-----separa por filas
                var rows = e.target.result.split("\n");
                // ----mientras existan filas
                for (var i = 0; i < rows.length; i++) {
                    //--- separa la fila i en columnas 
                    var cells = rows[i].split(",");
                    // si es mayor que 1
                    if (cells.length > 1) {

                        var row = table.insertRow(-1);
                        // mientras sea menor al tamaño de las columnas
                        for (var j = 0; j < cells.length; j++) {

                            var cell = row.insertCell(-1);

                            cell.innerHTML = cells[j];

                        }
                    }
                }

                var dvCSV = document.getElementById("dvCSV");

                dvCSV.innerHTML = "";

                dvCSV.appendChild(table);

            }
            reader.readAsText(fileUpload.files[0]);
            toastr.success("Se cargo el archivo correctamente","Operacion Exitosa");
        
    } else {
        toastr.error("Cargue un archivo CSV valido","Archivo incompatible");
    }
}
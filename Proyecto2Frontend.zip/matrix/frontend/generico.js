function toJSONString( form ) {
    var obj = {};
    var elements = form.querySelectorAll("input");
    //console.log(elements);
    for( var i = 0; i < elements.length; i++ ){
        var element = elements[i];
        var name = element.name;
        var value = element.value;
        if ( name ){
            obj[ name ] = value;
        }
    }
    return JSON.stringify( obj );

}

function toJSONString2( form ) {
    var obj = {};

    var elements2 = form.querySelectorAll("select");
    console.log(elements2);
    for( var i = 0; i < elements2.length; i++ ){
        var element2 = elements2[i];
        var name2 = element2.name;
        var value2 = element2.value;
        if ( name2 ){
            obj[ name2 ] = value2;
        }
    }

    var elements = form.querySelectorAll("input");
    console.log(elements);
    for( var i = 0; i < elements.length; i++ ){
        var element = elements[i];
        var name = element.name;
        var value = element.value;
        if ( name ){
            obj[ name ] = value;
        }
    }


    return JSON.stringify( obj );

}

function toJSONString3( form ) {
    var obj = {};


    var elements = form.querySelectorAll("input");
    console.log(elements);
    for( var i = 0; i < elements.length; i++ ){
        var element = elements[i];
        var name = element.name;
        var value = element.value;
        if ( name ){
            obj[ name ] = value;
        }
    }

    var elements2 = form.querySelectorAll("select");
    console.log(elements2);
    for( var i = 0; i < elements2.length; i++ ){
        var element2 = elements2[i];
        var name2 = element2.name;
        var value2 = element2.value;
        if ( name2 ){
            obj[ name2 ] = value2;
        }
    }


    return JSON.stringify( obj );

}

function getValueForm( id_form ){
    var form = document.getElementById( id_form );
    //console.log(form);
    var json = toJSONString(form);
    console.log(json);
    //console.log("NADA");
    return json;
}

function getValueForm2( id_form ){
    var form = document.getElementById( id_form );
    //console.log(form);
    var json = toJSONString2(form);
    console.log(json);
    //console.log("NADA");
    return json;
}

function getValueForm3( id_form ){
    var form = document.getElementById( id_form );
    //console.log(form);
    var json = toJSONString3(form);
    console.log(json);
    //console.log("NADA");
    return json;
}
const app2 = document.getElementById('root2');

//const logo = document.createElement('img');
//logo.src = 'logo.png';

//const container = document.createElement('div');
//container.setAttribute('class','container');

//app.appendChild(logo);
//app.appendChild(container);


// se crea una variable de peticion y se le asigna un objeto tipo XMLHttpRequest a ella
var request2 = new XMLHttpRequest();

//Se abre una nueva conexion, usando una peticion GET y la URL del endpoint
request2.open('GET','http://192.168.1.140:9098/proyecto1/getSal', true);

request2.onload = function (){
 //aqui se accesde al JSON
   var data2 = JSON.parse(this.response);

   
if (request2.status >= 200 && request2.status < 400){

  for ( var i = 0; i < data2.result.length; i++) {
     //const card = document.createElement('td');
     //card.setAttribute('class','card');
     //--------------------------------------------------------------<tr><td> y primera columna
     const tr4 = document.createElement('tr');
     const td4 = document.createElement('td');
     td4.setAttribute('id',i);
     td4.setAttribute('data-cont',data2.result[i].edificio);
     td4.textContent = data2.result[i].edificio;

     //--------------------------------------------------------------<td> y segunda columna
     const tdni = document.createElement('td');
     tdni.setAttribute('id',i);
     tdni.setAttribute('data-nom',data2.result[i].nombre);
     tdni.textContent = data2.result[i].nombre;


     //--------------------------------------------------------------<td> y tercera columna
     const tdsn = document.createElement('td');
     tdsn.setAttribute('id',i);
     tdsn.setAttribute('data-cont',data2.result[i].capacidad);
     tdsn.textContent = data2.result[i].capacidad;



    //const container = document.createElement('div');
    const td24 = document.createElement('td');

     const a4 = document.createElement('a');
     a4.setAttribute('href','#');
     a4.setAttribute('data-toggle','tooltip');
     a4.setAttribute('data-placement','top');
     a4.setAttribute('title','');
     a4.setAttribute('data-original-title','Editar');

     const di4 = document.createElement('i');
     di4.setAttribute('data-nom',data2.result[i].nombre);
     di4.setAttribute('data-edi',data2.result[i].edificio);
     di4.setAttribute('class','mdi mdi-settings');
     di4.setAttribute('data-toggle', 'modal');
     di4.setAttribute('data-target','#Modal233');

     const a24 = document.createElement('a');
     a24.setAttribute('href','#');
     a24.setAttribute('data-toggle','tooltip');
     a24.setAttribute('data-placement','top');
     a24.setAttribute('title','');
     a24.setAttribute('data-original-title','Eliminar');

     const di24 = document.createElement('i');
     di24.setAttribute('data-nom',data2.result[i].nombre);
     di24.setAttribute('data-edi',data2.result[i].edificio);
     di24.setAttribute('class','mdi mdi-close');
     di24.setAttribute('data-toggle', 'modal');
     di24.setAttribute('data-target','#Modal244');
     

     //const p = document.createElement('p');
     //movie.description = movie.description.substring(0,300);
     //p.textContent = `${movie.description}...`;
     /*<a href="#">
        <button type="button" class="btn btn-cyan btn-sm" data-toggle="modal" data-target="#Modal2">
          Editar
      </button>
      </a>
      <a href="#">
        <button type="button" class="btn btn-danger btn-sm">Eliminar</button>
      </a>  
      <a href="#" data-toggle="tooltip" data-placement="top" title="" data-original-title="Update">
                                                <i class="mdi mdi-check"></i>
                                            </a>
      
      */

     //container.appendChild(card);
     a4.appendChild(di4);
     a24.appendChild(di24);
     td24.appendChild(a4);
     td24.append(a24);
     tr4.appendChild(td4);
     tr4.appendChild(tdni);
     tr4.appendChild(tdsn);
     tr4.appendChild(td24);
     app2.appendChild(tr4);
     
     //card.appendChild(p);


   }
} else { 
  const tr4 = document.createElement('tr');
  const td4 = document.createElement('td');
  td4.setAttribute('id',i);
  td4.setAttribute('data-cont',data2.result[i].nombre);
  td4.textContent = "Error cargando lista";
  tr4.appendChild(td4); 
  app2.appendChild(tr4);  


 }
}


//se envia la peticion
request2.send();


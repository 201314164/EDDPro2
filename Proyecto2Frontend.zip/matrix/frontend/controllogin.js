function inicio_sesion(){
    httpPost(eplogin,getValueForm("loginform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Administrador autenticado", "Bienvenido");
            window.location.href="http://192.168.1.139:8080/main1.html";
            


        } else if(result.result =="2"){
            
            toastr.success("Usuario autenticado", "Bienvenido");
            window.location.href="http://192.168.1.139:8080/main2.html";
        
        
        }else{


            toastr.error("Usuario o Contraseña incorrectos","Error de autenticacion");
            

        }
    });
}



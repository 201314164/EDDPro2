function nuevoCate(){
    httpPost(niuCat,getValueForm("niuCatform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Catedratico Agregado", "Operacion Exitosa");

            

        }else if(result.result =="0"){

            toastr.error("Ya existe catedratico y codigo","Operacion Fallida");
    
        }else if(result.result =="2"){

            toastr.error("Ese codigo ya está en uso","Operacion Fallida");
    
        }else if(result.result =="3"){

            toastr.error("Ya existe catedratico, con codigo distinto","Operacion Fallida");
    
        
        
        }else{


            toastr.error("Ocurrio un error","Operacion Fallida");
            

        }
    });
}
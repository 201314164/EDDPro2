function nuevoSalo(json){
    httpPost(niuSal,json,function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Salon Argegado", "Operacion Exitosa");

            

        }else if(result.result == "0"){

        
            toastr.success("Se agrego un nuevo Edificio. ","Operacion Exitosa");
    
        
        
        }else{


            toastr.error("Ocurrio un error ","Operacion Fallida");
            

        }
    });
}








function Upload() {

    var fileUpload = document.getElementById("fileUpload");

    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt)$/;

    if (regex.test(fileUpload.value.toLowerCase())) {

        
            //-----crea lector
            var reader = new FileReader();

            reader.onload = function (e) {

                //-----separa por filas
                var filas = e.target.result.split("\n");
                
                //---- saca las cabeceras
                

                // ----mientras existan filas
                for (var i = 1; i < filas.length; i++) {
                    //--- separa la fila i en columnas 
                    var datos = filas[i].split(",");
                    // si es mayor que 1
                    if (datos.length > 1) {
                        /*console.log(cabeceras[0]);
                        console.log(datos[0]);
                        console.log(cabeceras[1]);
                        console.log(datos[1]);
                        console.log(cabeceras[2]);
                        console.log(datos[2]);
                        */

                        var obj = new Object();
                        obj.nombre = datos[0];
                        obj.nsalon  = datos[1];
                        obj.ncapacidad = datos[2];
                        var jsonString= JSON.stringify(obj);
                        console.log(jsonString);
                        nuevoSalo(jsonString);
                        // mientras sea menor al tamaño de las columnas
                        /*for (var j = 0; j < datos.length; j++) {

                            console.log(datos[j])

                            //inserta las celdas
                           

                        }*/
                    }
                }

                

            }
            reader.readAsText(fileUpload.files[0]);
            toastr.success("Se cargo el archivo correctamente","Operacion Exitosa");
        
    } else {
        toastr.error("Cargue un archivo CSV valido","Archivo incompatible");
    }
}
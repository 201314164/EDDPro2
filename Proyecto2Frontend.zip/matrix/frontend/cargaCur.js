function nuevoCurs(json){
    httpPost(niuCur,json,function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Curso Argegado", "Operacion Exitosa");

            

        }else if(result.result == "0"){

        
            toastr.error("Lista de catedraticos vacia ","Hacen Falta Recursos");

        }else if(result.result == "2"){

        
            toastr.error("El codigo ya esta en uso ","Operacion Fallida");
        
        }else if(result.result == "3"){

        
            toastr.error("Existe el curso con codigo distinto ","Operacion Fallida");
        
        
        }else{


            toastr.error("Ocurrio un error ","Operacion Fallida");
            

        }
    });
}



function Upload2() {

    var fileUpload = document.getElementById("fileUpload2");

    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt)$/;

    if (regex.test(fileUpload.value.toLowerCase())) {

        
            //-----crea lector
            var reader = new FileReader();

            reader.onload = function (e) {

                //-----separa por filas
                var filas = e.target.result.split("\n");
                
                //---- saca las cabeceras
                

                // ----mientras existan filas
                for (var i = 1; i < filas.length; i++) {
                    //--- separa la fila i en columnas 
                    var datos = filas[i].split(",");
                    // si es mayor que 1
                    if (datos.length > 1) {
                        /*console.log(cabeceras[0]);
                        console.log(datos[0]);
                        console.log(cabeceras[1]);
                        console.log(datos[1]);
                        console.log(cabeceras[2]);
                        console.log(datos[2]);
                        */

                        var obj = new Object();
                        obj.codigo = deldia(datos[0].replace(/\s+/g, ''));
                        obj.nombre  = deldia(datos[1]);
                        obj.catedra  = deldia(datos[2].replace(/\s+/g, ''));
                        var jsonString= JSON.stringify(obj);
                        console.log(jsonString);
                        nuevoCurs(jsonString);
                        // mientras sea menor al tamaño de las columnas
                        /*for (var j = 0; j < datos.length; j++) {

                            console.log(datos[j])

                            //inserta las celdas
                           

                        }*/
                    }
                }

                

            }
            reader.readAsText(fileUpload.files[0]);
            toastr.success("Se cargo el archivo correctamente","Operacion Exitosa");
        
    } else {
        toastr.error("Cargue un archivo CSV valido","Archivo incompatible");
    }
}
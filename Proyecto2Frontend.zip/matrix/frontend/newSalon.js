function nuevoSalo(){
    httpPost(niuSal,getValueForm2("niuSalform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Salon Argegado", "Operacion Exitosa");

            

        }else if(result.result == "0"){

        
            toastr.error("El edificio no existe. ","Hacen Falta Recursos");
    
        
        
        }else{


            toastr.error("Ocurrio un error ","Operacion Fallida");
            

        }
    });
}

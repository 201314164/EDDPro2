function deletSal(){
    httpPost(delSal,getValueForm("deleSalform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Salon Eliminado", "Operacion Exitosa");

            


    
        
        
        }else if (result.result =="0"){


            toastr.error("El Salon no existe","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
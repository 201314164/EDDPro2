function modifiSal(){
    httpPost(modSal,getValueForm("modiSalform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Se modifico el nombre del Salon", "Operacion Exitosa");

            


    
        
        


        }else if (result.result =="0"){


            toastr.error("Ya existe salon en el edificio","Operacion Fallida");

        }else if (result.result =="2"){


            toastr.error("No existe salon","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
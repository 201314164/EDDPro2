function modifiCat(){
    httpPost(modCat,getValueForm("modiCatform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Se modifico el nombre del Catedratico", "Operacion Exitosa");

            


    
        
        


        }else if (result.result =="0"){


            toastr.error("Catedratico no existe","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
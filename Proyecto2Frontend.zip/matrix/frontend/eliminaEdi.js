function deletEdi(){
    httpPost(delEdi,getValueForm("deleEdiform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Edificio Eliminado", "Operacion Exitosa");

            


    
        
        
        }else if (result.result =="0"){


            toastr.error("El edificio no existe","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
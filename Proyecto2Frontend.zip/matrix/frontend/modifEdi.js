function modifiEdi(){
    httpPost(modEdi,getValueForm("modiEdiform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Se modifico el nombre del edificio", "Operacion Exitosa");

            


    
        
        
        }else if (result.result =="0"){


            toastr.error("Existe un edificio con ese nombre","Operacion Fallida");

        }else if (result.result =="2"){


            toastr.error("Edificio no existe","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
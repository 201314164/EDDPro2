function deletCur(){
    httpPost(delCur,getValueForm("deleCurform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Curso Eliminado", "Operacion Exitosa");

            


    
        
        
        }else if (result.result =="0"){


            toastr.error("El Curso no existe","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
function modifiCur(){
    httpPost(modCur,getValueForm("modiCurform"),function(response){
        var result = JSON.parse(response);
        console.log(result);
        if(result.result == "1"){

            toastr.success("Se modifico el nombre del Curso", "Operacion Exitosa");

            


    
        
        


        }else if (result.result =="0"){


            toastr.error("Curso no existe","Operacion Fallida");
            

        }else{
            toastr.error("Ocurrio un error","Operacion Fallida");
        }
    });
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class ListaReservaciones {
    
    NodoHash cabeza;
    NodoHash fin;

    public ListaReservaciones() {
    
        this.cabeza = null;
        this.fin = null;
    
    }
    
    public void insertar(NodoHash niuReserv){
        
        insertar(niuReserv, this.cabeza);
        
    }

    private void insertar(NodoHash niuReserv, NodoHash hed) {
        
        if (hed == null){
            
            cabeza = niuReserv;
            fin = niuReserv;
            
        }else{
            
            if(fin != null){
                
                fin.setSig(niuReserv);
                fin = niuReserv;
                
            }
 
        }

    }
 
}

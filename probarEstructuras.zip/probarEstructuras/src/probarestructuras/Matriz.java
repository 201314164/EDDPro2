/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 *
 * @author gios
 */
public class Matriz {
    
    ListaCab cabeceras;
    ListaLat laterales;
    
    String graf = "";
    String cabz = "";
    String latz = "";
    String mismoR = "";

    public Matriz() {
    
        this.cabeceras = new ListaCab();
        this.laterales = new ListaLat();
    
    }
    
    
    public void insertar(destino newDes){
        
        insertar(newDes, this.cabeceras, this.laterales);
        
    }
    
    private void insertar(destino newDes, ListaCab cabeceras, ListaLat laterales){
        
        if(cabeceras.buscar(newDes.getCodigo()) == false && laterales.buscar(newDes.getCodigo()) == false){
            
            cabeceras.insertar(newDes);
            laterales.insertar(newDes);
            
            
        }
        
        
        
        
        
    }
    
    public void graficar(NodoCab hedC, NodoLat hedL){
        graf = "digraph Matriz{\nrankdir=TB;\nordering=\"out\"";
        
        if(hedC != null && hedL != null){
            graf += " \nnode [shape=box;color=\"Purple\"];";
            recorreGrafL(hedL);
            recorreGrafC(hedC);
            graf += "\n{rank =\"same\""+ mismoR +"}";
            mismoR = "";
            
            
            
        }else{
            
            graf+= " \nnode [shape=box;color=\"Purple\"];";
        }
        graf += "\n}";
        
        genDot(graf);
        
        
        
    }

    private void recorreGrafC(NodoCab hed) {
        if (hed != null){
            
            graf += "\n\"" + hed.getDestino().getCodigo() + "\"[label = \"" + hed.getDestino().getCodigo() +"\\n"+ hed.getDestino().getNombre() + "\"];";
            mismoR += " \""+hed.getDestino().getCodigo()+"\";";
            
            if(hed.getSig() != null){
                
                graf += "\n\"" + hed.getDestino().getCodigo() + "\" -> \"" + hed.getSig().getDestino().getCodigo() + "\"[color=\"Purple\" ];" ;
                recorreGrafC(hed.getSig());
                
            }
            
        }
        
        
        
        
    }

    private void recorreGrafL(NodoLat hed) {
        
        if (hed != null){
            
            graf += "\n\"" + hed.getDestino().getCodigo() + "L\"[label = \"" + hed.getDestino().getCodigo() +"\\n"+ hed.getDestino().getNombre() + "\"];";
            //mismoR += " \""+hed.getDestino().getCodigo()+"L\";";
            
            if(hed.getSig() != null){
                
                graf += "\n\"" + hed.getDestino().getCodigo() + "L\" -> \"" + hed.getSig().getDestino().getCodigo() + "L\"[color=\"Purple\" ];" ;
                recorreGrafL(hed.getSig());
                
            }
            
        }


    }
    
    
        private void genDot(String cod){
        
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+"Matriz.dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { "dot", "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/Matriz.dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/Matriz.png" };
                Process proc = new ProcessBuilder(command).start();
                //System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
        
        
        
        
    }
    
    
    
    
    
    
}

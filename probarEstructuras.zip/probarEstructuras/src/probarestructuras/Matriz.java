/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 *
 * @author gios
 */
public class Matriz {
    
    ListaCab cabeceras;
    ListaLat laterales;
    
    String graf = "";
    String cabz = "";
    String latz = "";
    String mismoR = "";

    public Matriz() {
    
        this.cabeceras = new ListaCab();
        this.laterales = new ListaLat();
    
    }
    
    
    public void insertar(destino newDes){
        
        insertar(newDes, this.cabeceras, this.laterales);
        
    }
    
    private void insertar(destino newDes, ListaCab cabeceras, ListaLat laterales){
        
        if(cabeceras.buscar(newDes.getCodigo()) == false && laterales.buscar(newDes.getCodigo()) == false){
            
            cabeceras.insertar(newDes);
            laterales.insertar(newDes);
            
            fill(newDes, cabeceras, laterales);
            
            
            
            
        }
        
        
        
        
        
    }
    
    public void nuevaRuta(String codP, String codD, String costo, String tiempo, boolean act ){
        
        nuevaRuta(codP, codD, costo, tiempo, this.laterales, act);
        
    }
    
    private void nuevaRuta(String codP, String codD, String costo, String tiempo ,ListaLat lat, boolean act){
        
        String id = codP+codD;
        
        String id2 = codD+codP;
        
        if(lat.cabeza != null){
            
            if(lat.buscar(codP)){
                NodoLat nodoL = lat.obtener(codP);
                
                if(nodoL.getFila().buscar(id)){
                    NodoMA nodoM = nodoL.getFila().obtener(id);
                    nodoM.getRuta().setValor(costo);
                    nodoM.getRuta().setTiempo(tiempo);
                    nodoM.setConex(act);
                    
                }
                
                
                
            }
            
            if(lat.buscar(codD)){
                NodoLat nodoL2 = lat.obtener(codD);
                
                if(nodoL2.getFila().buscar(id2)){
                    NodoMA nodoM2 = nodoL2.getFila().obtener(id2);
                    nodoM2.getRuta().setValor(costo);
                    nodoM2.getRuta().setTiempo(tiempo);
                    nodoM2.setConex(act);
                    
                }
                
                
                
            }
            
            
            
        
        }
        
        
        
        
        
    }
    
    
    
    
    private void fill(destino newDes, ListaCab cabeceras, ListaLat laterales) {
        
        String cod = newDes.getCodigo();
        
        NodoCab tempC = cabeceras.cabeza;
        while(tempC != null){
            
            NodoLat tempL = laterales.cabeza;
            while(tempL != null){
                
                String id = tempL.getDestino().getCodigo() + "" + tempC.getDestino().getCodigo();
                
                if(tempC.getColumna().buscar(id)){
                    //yaexiste
                }else{
                    
                    NodoMA niu = tempC.getColumna().insertar(new ruta(tempL.getDestino().getCodigo(),tempC.getDestino().getCodigo(),String.valueOf(Integer.MAX_VALUE),String.valueOf(Integer.MAX_VALUE),id));
                    tempL.getFila().insertar(niu);
                    
                }
                
                tempL = tempL.getSig();
                
            }
            
            tempC = tempC.getSig();
 
        }

    }
    
    
    
    
    
    
    //---------------------------------------------------------------------------------Para graficar
    
    public void graficar(NodoCab hedC, NodoLat hedL){
        graf = "digraph Matriz{\nrankdir=TB;\nordering=\"out\";\nC [ label = \"C\", style = invis ];";
        
        if(hedC != null && hedL != null){
            graf += " \nnode [shape=box;color=\"black\"; width=1.7];";
            recorreGrafL(hedL,true);
            recorreGrafC(hedC, true);
            graf += "\n{rank =\"same\""+ mismoR +"}";
            mismoR = "";
            
            NodoLat temp = hedL;
            
            while(temp != null){
                
                
                recorreFila(temp.getFila().cabeza,temp.getDestino().getCodigo(),true);
                graf += "\n{rank =\"same\""+ mismoR +"}";
                mismoR = "";
                
                temp = temp.getSig();
            }
            
            NodoCab temp2 = hedC;
            
            while(temp2 != null){
                
                
                recorreCol(temp2.getColumna().cabeza,temp2.getDestino().getCodigo(),true);
                
                
                temp2 = temp2.getSig();
            }
            
            
            
        }else{
            
            graf+= " \nnode [shape=box;color=\"black\"];";
        }
        graf += "\n}";
        
        genDot(graf);
        
        
        
    }

    private void recorreGrafC(NodoCab hed, boolean ichi) {
        if (hed != null){
            
            graf += "\n\"" + hed.getDestino().getCodigo() + "\"[label = \"" + hed.getDestino().getCodigo() +"\\n"+ hed.getDestino().getNombre() + "\"];";
            mismoR += " \""+hed.getDestino().getCodigo()+"\";";
            
            if(ichi){
                
                graf += "\n C -> \"" + hed.getDestino().getCodigo() + "\"[ style = invis ];" ;
                mismoR += " C;";
                
            }
            
            
            if(hed.getSig() != null){
                
                graf += "\n\"" + hed.getDestino().getCodigo() + "\" -> \"" + hed.getSig().getDestino().getCodigo() + "\"[color=\"black\" ];" ;
                recorreGrafC(hed.getSig(), false);
                
            }
            
        }
        
        
        
        
    }

    private void recorreGrafL(NodoLat hed, boolean ichi) {
        
        if (hed != null){
            
            graf += "\n\"" + hed.getDestino().getCodigo() + "L\"[label = \"" + hed.getDestino().getCodigo() +"\\n"+ hed.getDestino().getNombre() + "\"];";
            //mismoR += " \""+hed.getDestino().getCodigo()+"L\";";
            
            if(ichi){
               graf += "\n C -> \"" + hed.getDestino().getCodigo() + "L\"[ style = invis ];" ; 
                
            }
            
            if(hed.getSig() != null){
                
                graf += "\n\"" + hed.getDestino().getCodigo() + "L\" -> \"" + hed.getSig().getDestino().getCodigo() + "L\"[color=\"black\" ];" ;
                recorreGrafL(hed.getSig(), false);
                
            }
            
        }


    }
    
    
    private void recorreFila(NodoMA hed, String cabeza, boolean ichi){
        
        if(hed != null){
            
            if(hed.isConex()){
                graf += "\n\"" + hed.getRuta().getId() + "\"[label = \"$" + hed.getRuta().getValor() +" - "+ hed.getRuta().getTiempo() + "min\"];";  
            }else{
                graf += "\n\"" + hed.getRuta().getId() + "\"[label = \"0 - 0\"];";  
                
            }
            
            
            
            //graf += "\n\"" + hed.getRuta().getId() + "\"[label = \"" + hed.getRuta().getId() + "\"];";
            mismoR += " \""+hed.getRuta().getId()+"\";";
            
            if(ichi){
                graf += "\n\"" + cabeza + "L\" -> \"" + hed.getRuta().getId() + "\"[color=\"black\" ];" ;
                mismoR += " \""+cabeza+"L\";";
                
            }
            
            if(hed.getDer() != null){
                
                graf += "\n\"" + hed.getRuta().getId() + "\" -> \"" + hed.getDer().getRuta().getId() + "\"[color=\"black\" ];" ;
                if(ichi == false){
                  graf += "\n\"" + hed.getRuta().getId() + "\" -> \"" + hed.getIzq().getRuta().getId() + "\"[color=\"black\" ];" ;  
                }
                recorreFila(hed.getDer(),"", false);
                
            }else{
                
                graf += "\n\"" + hed.getRuta().getId() + "\" -> \"" + hed.getIzq().getRuta().getId() + "\"[color=\"black\" ];" ;  
            }

        }
  
    }
    
    private void recorreCol(NodoMA hed,String cabeza,boolean ichi){
        
        if (hed != null){
            
            if (ichi){
                graf += "\n\"" + cabeza + "\" -> \"" + hed.getRuta().getId() + "\"[color=\"black\" ];" ;
                
            }
            
            if(hed.getAba() != null){
                
                graf += "\n\"" + hed.getRuta().getId() + "\" -> \"" + hed.getAba().getRuta().getId() + "\"[color=\"black\" ];" ;
                if(ichi == false){
                  graf += "\n\"" + hed.getRuta().getId() + "\" -> \"" + hed.getArr().getRuta().getId() + "\"[color=\"black\" ];" ;  
                }
                recorreCol(hed.getAba(),"", false);
                
                
            }else{
                
                graf += "\n\"" + hed.getRuta().getId() + "\" -> \"" + hed.getArr().getRuta().getId() + "\"[color=\"black\" ];" ;  
            }
            
            
            
        }
        
        
    }
    
    
        private void genDot(String cod){
        
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+"Matriz.dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { "dot", "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/Matriz.dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/Matriz.png" };
                Process proc = new ProcessBuilder(command).start();
                //System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
        
        
        
        
    }


    
    
    
    
    
}

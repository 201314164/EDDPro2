/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoB {
    
    private int noF;
    private boolean hoja;
    
    private listaFacturas facturas;
    
    private HijosB hijos;
    
    private NodoB sig;
    
    private NodoB ante;
    
    private int peso;

    public NodoB() {
    
        this.noF = 0;
        this.hoja = true;
        this.peso = 0;
        
        this.facturas = new listaFacturas();
        this.hijos = new HijosB();
        
        this.sig = null;
        this.ante = null;
    
    
    }
    
    public void insertarFactura(factura niuFac){
        
        this.noF = this.noF + 1;
        this.facturas.insertar(niuFac);
        
        
    }
    
    public void eliminarFactura(String cod){
        
        this.noF = this.noF -1;
        this.facturas.eliminar(cod);
        
        
    }

    /**
     * @return the noNodos
     */
    public int getNoF() {
        return noF;
    }

    /**
     * @param noNodos the noNodos to set
     */
    public void setNoF(int noF) {
        this.noF = noF;
    }

    /**
     * @return the hoja
     */
    public boolean isHoja() {
        return hoja;
    }

    /**
     * @param hoja the hoja to set
     */
    public void setHoja(boolean hoja) {
        this.hoja = hoja;
    }

    /**
     * @return the facturas
     */
    public listaFacturas getFacturas() {
        return facturas;
    }

    /**
     * @param facturas the facturas to set
     */
    public void setFacturas(listaFacturas facturas) {
        this.facturas = facturas;
    }

    /**
     * @return the hijos
     */
    public HijosB getHijos() {
        return hijos;
    }

    /**
     * @param hijos the hijos to set
     */
    public void setHijos(HijosB hijos) {
        this.hijos = hijos;
    }

    /**
     * @return the sig
     */
    public NodoB getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoB sig) {
        this.sig = sig;
    }

    /**
     * @return the ante
     */
    public NodoB getAnte() {
        return ante;
    }

    /**
     * @param ante the ante to set
     */
    public void setAnte(NodoB ante) {
        this.ante = ante;
    }

    /**
     * @return the peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(int peso) {
        this.peso = peso;
    }

    


    
    
    
}

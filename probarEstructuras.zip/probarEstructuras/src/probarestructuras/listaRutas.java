/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class listaRutas {
    
    private String inicio;
    private String destino;
    private String Ninicio;
    private String Ndestino;
    
    private NodoRuta mejor;
    
    NodoRuta cabeza;
    NodoRuta fin;

    public listaRutas() {
        
        this.inicio = "";
        this.destino = "";
        this.Ninicio = "";
        this.Ndestino = "";
        
    
        this.cabeza = null;
        this.fin = null;
    
    }

    public listaRutas(String inicio, String destino) {
        this.inicio = inicio;
        this.destino = destino;
        this.cabeza = null;
        this.fin = null;
    }
    
    
    
    
    public void insertar(NodoRuta ruta){
        
        NodoRuta copia = new NodoRuta();
        copia.setCosto(ruta.getCosto());
        copia.setTiempo(ruta.getTiempo());
        NodoDestino temp = ruta.getRutas().cabeza;
        while(temp != null){
            
            copia.getRutas().insertar(temp.getDestino());
            
            temp = temp.getSig();
        }
        
        
        
        insertar(copia, this.cabeza,this.fin);
        
    }

    private void insertar(NodoRuta niu,  NodoRuta hed, NodoRuta teil) {
        
        if (hed == null){

            cabeza = niu;
            fin = niu;
            
        }else{
            
            if(teil != null){
  
                fin.setSig(niu);
                fin = niu;
  
            }
 
        }

    }

    /**
     * @return the inicio
     */
    public String getInicio() {
        return inicio;
    }

    /**
     * @param inicio the inicio to set
     */
    public void setInicio(String inicio) {
        this.inicio = inicio;
    }

    /**
     * @return the destino
     */
    public String getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(String destino) {
        this.destino = destino;
    }

    /**
     * @return the Ninicio
     */
    public String getNinicio() {
        return Ninicio;
    }

    /**
     * @param Ninicio the Ninicio to set
     */
    public void setNinicio(String Ninicio) {
        this.Ninicio = Ninicio;
    }

    /**
     * @return the Ndestino
     */
    public String getNdestino() {
        return Ndestino;
    }

    /**
     * @param Ndestino the Ndestino to set
     */
    public void setNdestino(String Ndestino) {
        this.Ndestino = Ndestino;
    }

    /**
     * @return the mejor
     */
    public NodoRuta getMejor() {
        return mejor;
    }

    /**
     * @param mejor the mejor to set
     */
    public void setMejor(NodoRuta mejor) {
        this.mejor = mejor;
    }
    
    
    
    
    
    
    
    
}

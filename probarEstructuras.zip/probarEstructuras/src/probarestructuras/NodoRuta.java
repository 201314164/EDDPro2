/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoRuta {
    
    private listaDestinos rutas;
    
    private int costo;
    private int tiempo;
    
    private NodoRuta sig;

    public NodoRuta() {
        
        this.costo = 0;
        this.tiempo = 0;
    
        this.rutas = new listaDestinos();
        this.sig = null;
    
    }

    public NodoRuta(listaDestinos rutas) {
        
        this.rutas = rutas;
        this.sig = null;
        
    }
    
    public void addRuta(destino newDes){
        
        this.rutas.insertar(newDes);
        
    }

    /**
     * @return the rutas
     */
    public listaDestinos getRutas() {
        return rutas;
    }

    /**
     * @param rutas the rutas to set
     */
    public void setRutas(listaDestinos rutas) {
        this.rutas = rutas;
    }

    /**
     * @return the sig
     */
    public NodoRuta getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoRuta sig) {
        this.sig = sig;
    }

    /**
     * @return the costo
     */
    public int getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(int costo) {
        this.costo = costo;
    }

    /**
     * @return the tiempo
     */
    public int getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}

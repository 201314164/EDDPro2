/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class fila {
    
    NodoMA cabeza;
    NodoMA fin;

    public fila() {
    
        this.cabeza = null;
        this.fin = null;
    
    }
    
    public NodoMA insertar(ruta newRut){
        
        return insertar(newRut, this.cabeza);
        
    }
    
    private NodoMA insertar(ruta newRut, NodoMA hed){
        
        NodoMA nuevo = null;
        
        if (hed == null){
            
            nuevo = new NodoMA(newRut);
            cabeza = nuevo;
            fin = nuevo;
            
            
            
            
        }else{
            
            if(fin != null){
                
                nuevo = new NodoMA(newRut);
                fin.setDer(nuevo);
                nuevo.setIzq(fin);
                fin = nuevo;   
                
                
                
            }
            
        }
        
        return nuevo;
        
        
    }
    
    public void insertar(NodoMA nodo){
        
        insertar(nodo, this.cabeza);
        
    }
    
    private void insertar(NodoMA nodo, NodoMA hed){
        
        
        
        if (hed == null){
            
            
            cabeza = nodo;
            fin = nodo;
            
            
            
            
        }else{
            
            if(fin != null){
                
                
                fin.setDer(nodo);
                nodo.setIzq(fin);
                fin = nodo;   
                
                
                
            }
            
        }
        
        
        
        
    }
    
    
    
}

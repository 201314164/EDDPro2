/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class fila {
    
    NodoMA cabeza;
    NodoMA fin;

    public fila() {
    
        this.cabeza = null;
        this.fin = null;
    
    }
    
    public NodoMA insertar(ruta newRut){
        
        return insertar(newRut, this.cabeza, this.fin);
        
    }
    
    private NodoMA insertar(ruta newRut, NodoMA hed, NodoMA teil){
        
        NodoMA nuevo = null;
        
        if (hed == null){
            
            nuevo = new NodoMA(newRut);
            cabeza = nuevo;
            fin = nuevo;
            
        }else{
            
            String id = newRut.getId();

            if(id.compareTo(hed.getRuta().getId()) < 0 || id.compareTo(hed.getRuta().getId()) == 0 ){
                
                if(id.compareTo(hed.getRuta().getId()) == 0){
                    //ya existe
                    
                }else{
                    //va antes de la cabeza
                    nuevo = new NodoMA(newRut);
                    nuevo.setDer(cabeza);
                    cabeza.setIzq(nuevo);
                    cabeza = nuevo;
                
                }
                
            } else if(id.compareTo(teil.getRuta().getId()) > 0 || id.compareTo(teil.getRuta().getId()) == 0 ){
                
                if(id.compareTo(teil.getRuta().getId()) == 0){
                    //ya existe
                 
                }else{
                    //va despues del final
                    nuevo = new NodoMA(newRut);
                    fin.setDer(nuevo);
                    nuevo.setIzq(fin);
                    fin = nuevo;
 
                }

            }else{
                
                NodoMA ante = hed;
                NodoMA curr = hed.getDer();
                while(curr != fin && id.compareTo(curr.getRuta().getId()) > 0){
                    ante = curr;
                    curr = curr.getDer();
               
                }
                
                if(id.compareTo(curr.getRuta().getId()) == 0){
                    //Ya existe  
                }else{
                    
                    nuevo = new NodoMA(newRut);
                    ante.setDer(nuevo);
                    nuevo.setIzq(ante);
                    nuevo.setDer(curr);
                    curr.setIzq(nuevo);
                    
   
                }
 
            }

        }
        
        return nuevo;
        
        
    }
    
    public void insertar(NodoMA nodo){
        
        insertar(nodo, this.cabeza, this.fin);
        
    }
    
    private void insertar(NodoMA nodo, NodoMA hed, NodoMA teil){
        
        
        
        if (hed == null){
            
            
            cabeza = nodo;
            fin = nodo;
            
        }else{
            
            String id = nodo.getRuta().getId();

            if(id.compareTo(hed.getRuta().getId()) < 0 || id.compareTo(hed.getRuta().getId()) == 0 ){
                
                if(id.compareTo(hed.getRuta().getId()) == 0){
                    //ya existe
                    
                }else{
                    //va antes de la cabeza
                    
                    nodo.setDer(cabeza);
                    cabeza.setIzq(nodo);
                    cabeza = nodo;
                
                }
                
            } else if(id.compareTo(teil.getRuta().getId()) > 0 || id.compareTo(teil.getRuta().getId()) == 0 ){
                
                if(id.compareTo(teil.getRuta().getId()) == 0){
                    //ya existe
                 
                }else{
                    //va despues del final
                    
                    fin.setDer(nodo);
                    nodo.setIzq(fin);
                    fin = nodo;
 
                }

            }else{
                
                NodoMA ante = hed;
                NodoMA curr = hed.getDer();
                while(curr != fin && id.compareTo(curr.getRuta().getId()) > 0){
                    ante = curr;
                    curr = curr.getDer();
               
                }
                
                if(id.compareTo(curr.getRuta().getId()) == 0){
                    //Ya existe  
                }else{
                    
                    
                    ante.setDer(nodo);
                    nodo.setIzq(ante);
                    nodo.setDer(curr);
                    curr.setIzq(nodo);
   
                }
 
            }

        }
        
        
        
        
    }
    
    
    public boolean buscar(String cod){
        
        return buscar(cod, this.cabeza);
        
        
    }
    
    private boolean buscar(String dest, NodoMA hed){
        
        if (hed == null){
            return false;
        }else{
            
            NodoMA temp = hed;
            while(temp != null){
                if(temp.getRuta().getId().equals(dest)){
                    return true;
                }else{
                    temp = temp.getDer();
                }
                
                
                
            }
            
            
        }
        return false;
        
        
        
        
    }
    
    
    public NodoMA obtener(String cod){
        
        return obtener(cod, this.cabeza);
        
        
    }
    
    private NodoMA obtener(String dest, NodoMA hed){
        
        if (hed == null){
            return null;
        }else{
            
            NodoMA temp = hed;
            while(temp != null){
                if(temp.getRuta().getId().equals(dest)){
                    return temp;
                }else{
                    temp = temp.getDer();
                }
                
                
                
            }
            
            
        }
        return null;
        
        
        
        
    }
    
    
    
}

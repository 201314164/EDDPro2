/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class Dijkstra {
    
    public Grafo caminoMasCorto(Grafo grafo, NodoAdy inicio){
        inicio.setPeso(0);
        inicio.setTiempo(0);
        inicio.setCosto(0);
        
        
        listaSimple visitado = new listaSimple();
        listaSimple noVisitado = new listaSimple();
        
        noVisitado.insertarUnicosv2(inicio);
        
        while(noVisitado.esVacia() == false){
//            System.out.println("-----Visitados----");
//            NodoAdy temp2 = visitado.cabeza;
//            while(temp2 != null){
//                
//                System.out.println("--"+temp2.getDestino().getNombre()+"--"+temp2.getDestino().getCodigo());
//                
//                temp2 = temp2.getSig();
//            }
//            System.out.println("--------------------");
//            System.out.println("-----NoVisitados----");
//            NodoAdy temp = noVisitado.cabeza;
//            while(temp != null){
//                
//                System.out.println("--"+temp.getDestino().getNombre()+"--"+temp.getDestino().getCodigo());
//                
//                temp = temp.getSig();
//            }
//            System.out.println("--------------------");
            
            
            NodoAdy actual = nodoCercano(noVisitado.cabeza);
            
//            if(actual == null){
//                System.out.println("null");
//            }else{
//                System.out.println(actual.getDestino().getNombre()+"-+-+-+-+-");
//            }
            
            
            noVisitado.eliminar(actual.getDestino().getCodigo());
            
            NodoLady nodosAdyacentes = actual.getAdyacentes().cabeza;
            while(nodosAdyacentes != null){
               
                NodoAdy nodoAdyacente = nodosAdyacentes.getDestino();
                int pesoAdyacente = nodosAdyacentes.getPeso();
                int tiempo = nodosAdyacentes.getTiempo();
                int costo = nodosAdyacentes.getCosto();
                
                if(!visitado.buscar(nodoAdyacente.getDestino().getCodigo())){
//                    System.out.println("----actual: " + actual.getDestino().getNombre() + " Adyacente: " + nodoAdyacente.getDestino().getNombre()) ; 
                    distanciaMinima(nodoAdyacente, pesoAdyacente, actual ,tiempo, costo);
                    noVisitado.insertarUnicosv2(nodoAdyacente);
                    
                }
                
                nodosAdyacentes = nodosAdyacentes.getSig();
                
            }
            
            visitado.insertarUnicosv2(actual);
            
        }
        
        return grafo;
        
    }

    private NodoAdy nodoCercano(NodoAdy hed) {
        NodoAdy nodoCercano = null;
        int pesoMin = Integer.MAX_VALUE;
        
        NodoAdy temp = hed;
        while(temp != null){
//            System.out.println(temp.getDestino().getCodigo());
            int pesoNodo = temp.getPeso();
            
            if(pesoNodo < pesoMin){
                
                pesoMin = pesoNodo;
                nodoCercano = temp;
                
            }
            
            temp = temp.getSig();
        }
        
        return nodoCercano;
        
    }

    private void distanciaMinima(NodoAdy nodoAdyacente, int pesoAdyacente, NodoAdy actual , int tiempo, int costo) {
        
        int pesoActual = actual.getPeso();

        if(pesoActual + pesoAdyacente < nodoAdyacente.getPeso()){
            
//            System.out.println("-------camino--------");
//            NodoAdy temp =  actual.getCamino().cabeza;
//            while (temp != null){
//                System.out.print(temp.getDestino().getNombre() + " --> ");
//                temp = temp.getSig();
//            }
//            System.out.println("---------------------");

            //System.out.println("agregando camino a ------------------ -> " + nodoAdyacente.getDestino().getNombre());

            
            nodoAdyacente.setPeso(pesoActual + pesoAdyacente);
            nodoAdyacente.setTiempo(tiempo + actual.getTiempo());
            nodoAdyacente.setCosto(costo + actual.getCosto());
 
            //System.out.println("-----------------------adyacente---Tiempo: " +tiempo+ " Costo: "+ costo + "------actual---Tiempo" +actual.getTiempo()+ " Costo: "+ actual.getCosto() );
            listaSimple caminoCorto = new listaSimple(actual.getCamino().cabeza);
            caminoCorto.insertarUnicosv2(actual);
            nodoAdyacente.setCamino(caminoCorto);
            int x = 1+1;
 
        }
        
    }
    
    
    
    
    
    public listaRutas posiblesRutas(NodoAdy ini, NodoAdy fin){
        
        int tiempo = 0;
        int costo = 0;
        
        System.out.println(tiempo + "-" + costo);
        
        listaSimple visitado = new listaSimple();
        
        listaRutas rutas = new listaRutas();
        rutas.setInicio(ini.getDestino().getCodigo());
        rutas.setNinicio(ini.getDestino().getNombre());
        rutas.setDestino(fin.getDestino().getCodigo());
        rutas.setNdestino(fin.getDestino().getNombre());
        
        
        listaDestinos ruta = new listaDestinos();
        
        ruta.insertar(ini.getDestino());
        
        posiblesRutas(ini, fin, visitado, ruta, rutas, tiempo, costo);
        
        return rutas;
        
    }

    private void posiblesRutas(NodoAdy ini, NodoAdy fin, listaSimple visitado, listaDestinos ruta, listaRutas rutas , int tiempo, int costo) {

        
        visitado.insertarUnicosv2(ini);
        
        
        
        if(ini.getDestino().getCodigo().equals(fin.getDestino().getCodigo())){
            
//            System.out.println(tiempo + "-" + costo);
            
            rutas.insertar(new NodoRuta(ruta, costo, tiempo));
            
            
            costo = 0;
            tiempo = 0;
            visitado.eliminar(ini.getDestino().getCodigo());
            
            
            
            
            return;
            
        }
        
        
        NodoLady nodosAdyacentes = ini.getAdyacentes().cabeza;
        while(nodosAdyacentes != null){
            
            NodoAdy nodoAdyacente = nodosAdyacentes.getDestino();
            if(!visitado.buscar(nodoAdyacente.getDestino().getCodigo())){
                
                ruta.insertar(nodoAdyacente.getDestino());
                
                System.out.println(tiempo + "-" + costo);
                
                tiempo = tiempo + nodosAdyacentes.getTiempo();
                costo = costo + nodosAdyacentes.getCosto();
                
                posiblesRutas(nodoAdyacente, fin, visitado, ruta, rutas ,tiempo, costo);
                
                tiempo = tiempo - nodosAdyacentes.getTiempo();
                costo = costo - nodosAdyacentes.getCosto();
                
                ruta.eliminar(nodoAdyacente.getDestino().getCodigo());
                
            }
                
                
            nodosAdyacentes = nodosAdyacentes.getSig();
            
            
        }
        
        visitado.eliminar(ini.getDestino().getCodigo());
        
        
        
    }
    
    
    
    
    
    
    
}

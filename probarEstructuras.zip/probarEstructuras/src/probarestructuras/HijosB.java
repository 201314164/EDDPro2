/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class HijosB {
    
    NodoB cabeza;
    NodoB fin;

    public HijosB() {
        
    this.cabeza = null;
    this.fin = null;
    
    
    }
    
    
    public void insertar(NodoB nodo){
        
        NodoB copia = new NodoB();
        copia.setFacturas(nodo.getFacturas());
        copia.setHijos(nodo.getHijos());
        copia.setHoja(nodo.isHoja());
        copia.setNoF(nodo.getNoF());
        

        insertar(copia, this.cabeza);
        
    }

    private void insertar(NodoB nodo, NodoB hed) {
        
        if(cabeza == null){
            
            cabeza = nodo;
            fin = nodo;
            
        }else{
            
            if(fin != null){
                
                fin.setSig(nodo);
                nodo.setAnte(fin);
                fin = nodo;
                
                
                
            }
            
            
            
        }



    }
    
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class usuario {
    
    private String id;
    private String pass;
    private String nombre;
    private String reservas;

    public usuario() {
        this.id = "";
        this.nombre = "";
        this.pass = "";
        this.reservas = "";
        
    }

    public usuario(String id, String pass, String nombre) {
        this.id = id;
        this.pass = pass;
        this.nombre = nombre;
        this.reservas = "";
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the pass
     */
    public String getPass() {
        return pass;
    }

    /**
     * @param pass the pass to set
     */
    public void setPass(String pass) {
        this.pass = pass;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the reservas
     */
    public String getReservas() {
        return reservas;
    }

    /**
     * @param reservas the reservas to set
     */
    public void setReservas(String reservas) {
        this.reservas = reservas;
    }
    
    
    
    
    
    
    
    
    
}

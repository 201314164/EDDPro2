/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gios
 */
public class AVL {
    
    NodoAVL raiz;
    String graf;
    
    //Se usa para devolverlo en la api al frontend
    List<usuario> resp = new ArrayList<>();
    

    public AVL() {
        
        this.raiz = null;
        
    }
    
    public boolean esVacio(){
        
        return this.raiz == null;
        
    }
    
    public void eliminar(){
        
        this.raiz = null;
        
    }
    
    public int altura(NodoAVL nodo){
        
        if( nodo == null){
            
            return -1;
            
        }else{
            
            return nodo.getAltura();
            
        }
        
    }
    
    public int mayor(int hizq, int hder){
        
        if(hizq > hder){
            
            return hizq;
            
        }else{
            
            return hder;
            
        }
        
    }
    
    
    public void insertar(usuario newUsu){
        
        this.raiz = insertar( newUsu,this.raiz);
        
    }
    
    private NodoAVL insertar(usuario newUsu, NodoAVL nodo){
        
        if (nodo == null){
            
            nodo = new NodoAVL(newUsu);
            
        }else if(newUsu.getId().compareTo(nodo.getUsuario().getId()) < 0 ){
            
            nodo.setIzq(insertar(newUsu,nodo.getIzq()));
            if( altura(nodo.getIzq()) - altura(nodo.getDer()) == 2){
                if(newUsu.getId().compareTo(nodo.getIzq().getUsuario().getId()) < 0){
                    
                    nodo = rsizq( nodo );
                    
                }else {
                    
                    nodo = rdizq( nodo );
                    
                }
                
            }

        }else if(newUsu.getId().compareTo(nodo.getUsuario().getId()) > 0 ){
            
            nodo.setDer( insertar(newUsu, nodo.getDer() ) );
            int x = altura(nodo.getIzq()) - altura(nodo.getDer());
            System.out.println(x);
            if( altura(nodo.getDer()) - altura(nodo.getIzq()) == 2 ){
                
                if(newUsu.getId().compareTo(nodo.getDer().getUsuario().getId()) > 0){
                
                nodo = rsder(nodo);
                
                }else{
                    
                nodo = rdder(nodo);
                    
                }
                
                
                
            }
            
        }
        
        else{
            
            
            
        }
        
        nodo.setAltura(mayor(altura(nodo.getIzq()), altura(nodo.getDer())) + 1 );
        
        return nodo;
        
    }
    
    
    private NodoAVL rsizq( NodoAVL n2 ){
        
        NodoAVL n1 = n2.getIzq();
        n2.setIzq(n1.getDer());
        n1.setDer(n2);
        n2.setAltura( mayor( altura( n2.getIzq() ) , altura( n2.getDer() ) ) + 1 );
        n1.setAltura( mayor( altura( n1.getIzq() ) , n2.getAltura() ) + 1 );
        return n1;
        
    }
    
    private NodoAVL rsder( NodoAVL n1 ){
        
        NodoAVL n2 = n1.getDer();
        n1.setDer(n2.getIzq());
        n2.setIzq(n1);
        n1.setAltura( mayor( altura( n1.getIzq() ) , altura( n1.getDer() ) ) + 1 );
        n1.setAltura( mayor( altura( n2.getIzq() ) , n1.getAltura() ) + 1 );
        return n2;
        
        
    }
    
    
    private NodoAVL rdizq( NodoAVL n ){
        
        n.setIzq( rsder(n.getIzq()) );
        return rsizq(n);
        
    }
    
    private NodoAVL rdder ( NodoAVL n){
        
        n.setDer( rsizq( n.getDer() ) );
        return rsder( n );
        
    }
    
    public boolean buscar(String id){
        
        return buscar(id, this.raiz);
        
    }

    private boolean buscar(String id, NodoAVL raiz) {

        boolean flag = false;
        while (raiz != null){
            
            if(id.compareTo(raiz.getUsuario().getId()) < 0 ){
                raiz = raiz.getIzq();
            }else if(id.compareTo(raiz.getUsuario().getId()) > 0){
                raiz = raiz.getDer();
                
            }else{
                return true;
            }
            
            
            
        }
        return false;

    }
    
    public NodoAVL obtener(String id){
        
        return obtener(id, this.raiz);
        
    }
    
    private NodoAVL obtener(String id, NodoAVL raiz){
        
        
        NodoAVL ndd;
        
        while (raiz != null){
            
            if(id.compareTo(raiz.getUsuario().getId()) < 0 ){
                raiz = raiz.getIzq();
            }else if(id.compareTo(raiz.getUsuario().getId()) > 0){
                raiz = raiz.getDer();
                
            }else{
                return raiz;
            }
            
            
            
        }
        return null;
        
        
    }
    
    
    
    
    
    public void borrar(String id){
        
        this.raiz = borrar(id,this.raiz);
        
    }

    private NodoAVL borrar(String id, NodoAVL nodo){
        
        if (nodo == null){
            return nodo;
            
        }else{
            
          if (id.compareTo(nodo.getUsuario().getId()) < 0 ){
              nodo.setIzq( borrar(id, nodo.getIzq() ) );
              
              
          }else if(id.compareTo(nodo.getUsuario().getId()) > 0 ){
              nodo.setDer( borrar(id, nodo.getDer() ) );
              
              
          }else{
              
              if(nodo.getIzq() == null || nodo.getDer() == null){
                  
                  NodoAVL temp = null;
                  if( temp == nodo.getIzq()){
                      temp = nodo.getDer();
                      
                  }else{
                      temp = nodo.getIzq();
                      
                  }
                  
                  if (temp == null){
                      temp = nodo;
                      nodo = null;
                      
                  }else{
                      nodo = temp;
                      
                  }
                  
                  
                  
              }else{
                  
                  
                  NodoAVL temp = sucesor(nodo.getDer());
                  
                  nodo.getUsuario().setId(temp.getUsuario().getId());
                  nodo.getUsuario().setPass(temp.getUsuario().getPass());
                  nodo.getUsuario().setNombre(temp.getUsuario().getNombre());
                  
                  nodo.setDer( borrar(temp.getUsuario().getId(),nodo.getDer()) );
                  
              }
              
             
              
              
              
          }
            
             if(nodo == null){
                  return nodo;
              }else{
                  
                  nodo.setAltura(mayor(altura(nodo.getIzq()), altura(nodo.getDer())) + 1 );
                  System.out.println("--------------------------------------------");
                  
                  if( altura(nodo.getIzq()) - altura(nodo.getDer()) == 2 ){
                      
                      if(balance(nodo.getIzq()) >= 0){
                          return(rsizq(nodo));
                          
                      }else if(balance(nodo.getIzq()) < 0){
                          return(rdizq(nodo));
                          
                      }
                      
                      
                      
                      
                      
                  }else if (altura(nodo.getDer()) - altura(nodo.getIzq()) == 2){
                      
                      
                      if(balance(nodo.getDer()) <= 0){
                          return(rsder(nodo));
                          
                      }else if(balance(nodo.getDer()) > 0){
                          return(rdder(nodo));
                          
                      }
                      
                      
                      
                  }
                  
                  
                  
                  
              }
            
            
            
            
        }
        
        return nodo;
        
    }
    
    private int balance(NodoAVL nodo){
        
        if(nodo == null){
            return 0;
        }else{
            return (altura(nodo.getIzq()) - altura(nodo.getDer()));
        }
        
        
    }
    
    
    private NodoAVL sucesor(NodoAVL nodo) {
        NodoAVL temp = nodo;
        
        while(temp.getIzq() != null){
            temp = temp.getIzq();

        }
        
        return temp;
        
        
    }
    
    
    public List<usuario> recorrer(){
        
        return recorrer(this.raiz);
        
    }
    
    private List<usuario> recorrer( NodoAVL nodo){
        
        
        
        if (nodo == null){
            resp.clear();
            return resp;
            
        }else{
            
           resp.clear();
           inorden(nodo);
           return resp;
            
        }
        
        
        
    }
    
    
    private void inorden(NodoAVL nodo){
        
        if(nodo != null){
            inorden(nodo.getIzq());
            resp.add(nodo.getUsuario());
            inorden(nodo.getDer());
            
        }
        
        
    }
    
    
    
    //---------------------------------------------------------------------------------------------------Metodos de graficacion
    
    public void graficar(NodoAVL raiz){
        graf = "digraph AVL{ \n node [shape=record fontsize=18 fontname=\"arial\"]; \nrankdir=TB;";
        if(raiz != null){
            graf += " \nsubgraph cluster1 { \nnode [shape=record;color=\"Orange\"] \nlabel = \"Usuarios\";";
            grafAVL(raiz);
            graf += "}";
            
        }else{
            graf += " \nsubgraph cluster1 { \nnode [shape=record;];color=\"Orange\";}";
            
        }
        graf += "}";
        genDot(graf);
        
        
    }
    
    private void grafAVL(NodoAVL raiz){
        if (raiz != null){
     
            graf += "\n" + raiz.getUsuario().getId() + "[shape=record; label = \"<i>|<r>" + raiz.getUsuario().getId()+"\\n"+raiz.getUsuario().getNombre()+"\\n"+raiz.getUsuario().getPass()+"|<d> \"];";
            
            if(raiz.getIzq() != null){
                                
                graf += "\n" + raiz.getUsuario().getId() + ":i -> " + raiz.getIzq().getUsuario().getId() + ":r[color=\"Orange\"];";
                grafAVL(raiz.getIzq());

            }
            
            if(raiz.getDer() != null){
                                
                graf += "\n" + raiz.getUsuario().getId() + ":d -> " + raiz.getDer().getUsuario().getId() + ":r[color=\"Orange\"];";
                grafAVL(raiz.getDer());

            }

        }

    }
    
    
    private void genDot(String cod){
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+"AVL.dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { "dot", "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/AVL.dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/AVL.png" };
                Process proc = new ProcessBuilder(command).start();
                System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
        
        
        
        
        
    }


    
    
    
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class listaSimple {
    
    NodoAdy cabeza;
    NodoAdy fin;

    public listaSimple() {
    
        this.cabeza = null;
        this.fin = null;
    
    }

    public listaSimple(NodoAdy hed) {
        
        NodoAdy temp = hed;
        while(temp != null){
            NodoAdy copia = new NodoAdy();
            copia.setAdyacentes(temp.getAdyacentes());
            copia.setCamino(temp.getCamino());
            copia.setDestino(temp.getDestino());
            copia.setPeso(temp.getPeso());
            
            insertarUnicosv2(temp);
            
            temp = temp.getSig();
        }
        
    }
    
    
  
    
    
    public void insertar(NodoAdy niu){
        
        insertar(niu,this.cabeza,this.fin);
        
    }

    private void insertar(NodoAdy niu, NodoAdy hed, NodoAdy teil) {
        
        if (hed == null){
            
            cabeza = niu;
            fin = niu;
            
        }else{
            
            if(teil != null){
                
                fin.setSig(niu);
                fin = niu;
  
            }
 
        }

    }
    
    public void insertarUnicos(NodoAdy niu){
        if(buscar(niu.getDestino().getCodigo())){
            //ya existe
        }else{
            
            
            
          insertar(niu,this.cabeza,this.fin);  
        }
        
        
    }
    
    public void insertarUnicosv2(NodoAdy niu){
        if(buscar(niu.getDestino().getCodigo())){
            //ya existe
        }else{
            NodoAdy copia = new NodoAdy();
            copia.setAdyacentes(niu.getAdyacentes());
            copia.setCamino(niu.getCamino());
            copia.setDestino(niu.getDestino());
            copia.setPeso(niu.getPeso());
            
            
          insertar(copia,this.cabeza,this.fin);  
        }
        
        
    }
    
    
    
    
    
    public void eliminar(String cod){
        
        eliminar(cod, this.cabeza,this.fin);
        
        
    }
    
    private void eliminar(String cod, NodoAdy hed, NodoAdy teil){
        
        if(hed != null){
            
            
            if(hed == teil){
                cabeza = null;
                fin = null;
            }else if(cabeza.getDestino().getCodigo().equals(cod)){
                
                NodoAdy temp = cabeza;
                cabeza = cabeza.getSig();
                temp.setSig(null);
 
            }else if(fin.getDestino().getCodigo().equals(cod)){
                
                NodoAdy temp = cabeza;
                while(temp.getSig() != fin){
                    
                    temp = temp.getSig();
                    
                }
                
                temp.setSig(null);
                fin = temp;
  
            }else{
                
                NodoAdy ante = cabeza;
                NodoAdy curr = cabeza.getSig();
                while(curr != null){
                    
                    if(curr.getDestino().getCodigo().equals(cod)){
                        
                        ante.setSig(curr.getSig());
                        
                    }else{
                        
                        ante = curr;
                        curr = curr.getSig();
                        
                    }

                }
 
            }

        }
 
    }
    
    
    public boolean buscar(String cod){
    
        return buscar(cod, this.cabeza, this.fin);
    
    }

    private boolean buscar(String cod, NodoAdy hed, NodoAdy teil) {
        
       if(hed == null){
           return false;
           
       } else{
           
           NodoAdy temp = hed;
           while(temp != null){
               if(temp.getDestino().getCodigo() == cod){
                   
                   return true;
                   
               }else{
                   
                   temp = temp.getSig();
                   
               }
               
               
               
           }
           
           
       }
        
       return false; 
       
    }
    
    public NodoAdy obtener(String cod){
    
        return obtener(cod, this.cabeza, this.fin);
    
    }

    private NodoAdy obtener(String cod, NodoAdy hed, NodoAdy teil) {
        
       if(hed == null){
           return null;
           
       } else{
           
           NodoAdy temp = hed;
           while(temp != null){
               if(temp.getDestino().getCodigo() == cod){
                   
                   return temp;
                   
               }else{
                   
                   temp = temp.getSig();
                   
               }
               
               
               
           }
           
           
       }
        
       return null; 
       
    }
    
    
    
    
    public boolean esVacia(){
        
        if(this.cabeza == null){
            return true;
        }else{
            return false;
        }
        
        
    }
    
    
    
    
    
}

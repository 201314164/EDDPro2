/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 *
 * @author gios
 */
public class ArbolB {
    
    NodoB raiz;
    
    String graf = "";
    String conex = "";

    public ArbolB() {
    
        this.raiz = new NodoB();
        this.raiz.setHoja(true);
        this.raiz.setNoF(0);
        graf = "";
        conex = "";
    }
    
    
    public void insertar(factura niuFac){
        
        insertar(niuFac, this.raiz);
        
        
    }

    private void insertar(factura niuFac, NodoB raiz) {
        System.out.println(raiz.getNoF());
        
        if(raiz.getNoF() == 4){
            System.out.println("Split!");
            
            
            NodoB nuevo = new NodoB();
            nuevo.getHijos().insertar(raiz);
            nuevo.setHoja(false);
            this.raiz = nuevo;
            split(nuevo, nuevo.getHijos().cabeza);
            
            
            
        }
        insertarANodo(raiz,niuFac);
        
        
        
        
    }

    private void split(NodoB otou, NodoB sepa) {
        
        NodoB nuevo = new NodoB();
        nuevo.setHoja(sepa.isHoja());
        
       
        
        nuevo.insertarFactura(sepa.getFacturas().cabeza.getSig().getSig().getFactura());
        nuevo.insertarFactura(sepa.getFacturas().cabeza.getSig().getSig().getSig().getFactura());
        System.out.println(nuevo.getNoF()+ "-----------------");
        sepa.eliminarFactura(sepa.getFacturas().cabeza.getSig().getSig().getSig().getFactura().getID());
        sepa.eliminarFactura(sepa.getFacturas().cabeza.getSig().getSig().getFactura().getID());
        
        if(sepa.isHoja() == false){
            
            
            nuevo.getHijos().insertar(sepa.getHijos().cabeza);
            nuevo.getHijos().insertar(sepa.getHijos().cabeza.getSig());
            nuevo.getHijos().insertar(sepa.getHijos().cabeza.getSig().getSig());
            
        }
        
        otou.getHijos().insertar(nuevo);
        otou.insertarFactura(sepa.getFacturas().cabeza.getSig().getFactura());
        sepa.eliminarFactura(sepa.getFacturas().cabeza.getSig().getFactura().getID());
        
int x = 1+1;        
        
        
    }

    private void insertarANodo(NodoB nodo, factura niuFac) {
        
        if(nodo.isHoja()){

            nodo.insertarFactura(niuFac);
            
            
            return;
        }
        
        NodoFactura tempF = nodo.getFacturas().cabeza;
        NodoB tempB = nodo.getHijos().cabeza;
        while(tempF != null){
            
            if(niuFac.getID().compareTo(tempF.getFactura().getID()) > 0){
                break;
                
            }else if(tempF.getSig() == null){
                tempB = tempB.getSig();
                break;
            }else{
                
                tempF = tempF.getSig();
                tempB = tempB.getSig();
            }
            
            
            
        }
        System.out.println("tmp -> "+ tempB.getNoF());
        if(tempB.getNoF() == 4){
            split(nodo, tempB);
            insertarANodo(nodo, niuFac);
            return;
        }
        
        insertarANodo(tempB,niuFac);
        
        
    }
            
    
    
    
    
    
    
    
    


    public void graficar(NodoB raiz){
        graf = "digraph B{ \n node [shape=record fontsize=18 fontname=\"arial\"]; \nrankdir=TB;";
        if(raiz != null){
            graf += " \nsubgraph cluster1 { \nnode [shape=record;color=\"Orange\"] \nlabel = \"Facturas\";";
            grafB(raiz);
            graf += conex;
            graf += "}";
            
        }else{
            graf += " \nsubgraph cluster1 { \nnode [shape=record;];color=\"Orange\";}";
            
        }
        graf += "}";
        genDot(graf);
        
        
    }

    private void grafB(NodoB raiz){
        if (raiz != null){
            
            NodoB temp3 = null;
            
            NodoFactura temp = raiz.getFacturas().cabeza;
            if(raiz.getHijos().cabeza != null){ 
            temp3 = raiz.getHijos().cabeza;
            conex += "\n\""+ raiz.getFacturas().cabeza.getFactura().getID()+"N\":"+temp.getFactura().getID() +" -> \""+temp3.getFacturas().cabeza.getFactura().getID() +"N\";" ;        

            }
            graf += "\n\"" + temp.getFactura().getID() + "N\"[shape=record; label = \" <" + temp.getFactura().getID() + ">|" + temp.getFactura().getID();
            
                
            temp = temp.getSig();
            
           
            
            

            while(temp != null){
                
                graf += "|<" + temp.getFactura().getID() + ">|"+ temp.getFactura().getID();
                
                if(temp3 != null){
               conex += "\n\""+ raiz.getFacturas().cabeza.getFactura().getID()+"N\":"+temp.getFactura().getID() +" -> "+temp3.getFacturas().cabeza.getFactura().getID() +";" ;        
                }
                
               
               temp = temp.getSig();
               
            }
            if(temp3 != null){
            if(temp3.getSig() != null){
                temp3 = temp3.getSig();
                conex += "\n\""+ raiz.getFacturas().cabeza.getFactura().getID()+"N\":FF -> \""+temp3.getFacturas().cabeza.getFactura().getID() +"N\";" ;        
            }
            }
            graf += "|<FF>\"]";
            NodoB temp2 = raiz.getHijos().cabeza;
            while(temp2 != null){
                
                
                //System.out.println(temp2.getFacturas().cabeza.getFactura().getID());
                    
                 
                
                
                grafB(temp2);
                temp2 = temp2.getSig();
            }
            
            
            

            
     
//            graf += "\n" + raiz.getUsuario().getId() + "[shape=record; label = \"<i>|<r>" + raiz.getUsuario().getId()+"\\n"+raiz.getUsuario().getNombre()+"\\n"+raiz.getUsuario().getPass()+"|<d> \"];";
//            
//            if(raiz.getIzq() != null){
//                                
//                graf += "\n" + raiz.getUsuario().getId() + ":i -> " + raiz.getIzq().getUsuario().getId() + ":r[color=\"Orange\"];";
//                grafAVL(raiz.getIzq());
//
//            }
//            
//            if(raiz.getDer() != null){
//                                
//                graf += "\n" + raiz.getUsuario().getId() + ":d -> " + raiz.getDer().getUsuario().getId() + ":r[color=\"Orange\"];";
//                grafAVL(raiz.getDer());
//
//            }

        }

    }
    
       private void genDot(String cod){
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+"AB.dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { "dot", "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/AB.dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/AB.png" };
                Process proc = new ProcessBuilder(command).start();
                System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
    
       }

    
    
}

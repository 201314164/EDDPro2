/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class listaFacturas {
    
    NodoFactura cabeza;
    NodoFactura fin;

    public listaFacturas() {
        
        this.cabeza = null;
        this.fin = null;
    
    
    }
    
    
    public void insertar(factura niuFac){
        
        insertar(niuFac, this.cabeza, this.fin);
        
    }

    private void insertar(factura niuFac, NodoFactura hed, NodoFactura teil) {
    
        if (hed == null){
            
            NodoFactura nuevo = new NodoFactura(niuFac);
            cabeza = nuevo;
            fin = nuevo;
            
        }else{
            
            String id = niuFac.getID();

            if(id.compareTo(hed.getFactura().getID()) < 0 || id.compareTo(hed.getFactura().getID()) == 0 ){
                
                if(id.compareTo(hed.getFactura().getID()) == 0){
                    //ya existe
                    
                }else{
                    //va antes de la cabeza
                    NodoFactura nuevo = new NodoFactura(niuFac);
                    nuevo.setSig(cabeza);
                    cabeza.setAnt(nuevo);
                    cabeza = nuevo;
                
                }
                
            } else if(id.compareTo(teil.getFactura().getID()) > 0 || id.compareTo(teil.getFactura().getID()) == 0 ){
                
                if(id.compareTo(teil.getFactura().getID()) == 0){
                    //ya existe
                 
                }else{
                    //va despues del final
                    NodoFactura nuevo = new NodoFactura(niuFac);
                    fin.setSig(nuevo);
                    nuevo.setAnt(fin);
                    fin = nuevo;
 
                }

            }else{
                
                NodoFactura ante = hed;
                NodoFactura curr = hed.getSig();
                while(curr != fin && id.compareTo(curr.getFactura().getID()) > 0){
                    ante = curr;
                    curr = curr.getSig();
               
                }
                
                if(id.compareTo(curr.getFactura().getID()) == 0){
                    //Ya existe  
                }else{
                    
                    NodoFactura nuevo = new NodoFactura(niuFac);
                    ante.setSig(nuevo);
                    nuevo.setAnt(ante);
                    nuevo.setSig(curr);
                    curr.setAnt(nuevo);
   
                }
 
            }

        }
 
    }
        
        
    public void eliminar(String cod){
        
        eliminar(cod, this.cabeza,this.fin);
        
        
    }
    
    private void eliminar(String cod, NodoFactura hed, NodoFactura teil){
        
        if(hed != null){
            
            
            if(hed == teil){
                cabeza = null;
                fin = null;
            }else if(cabeza.getFactura().getID().equals(cod)){
                
                NodoFactura temp = cabeza;
                cabeza = cabeza.getSig();
                cabeza.setAnt(null);
                temp.setSig(null);
 
            }else if(fin.getFactura().getID().equals(cod)){
                
                NodoFactura temp = cabeza;
                while(temp.getSig() != fin){
                    
                    temp = temp.getSig();
                    
                }
                
                temp.setSig(null);
                fin.setAnt(null);
                fin = temp;
  
            }else{
                
                NodoFactura ante = cabeza;
                NodoFactura curr = cabeza.getSig();
                while(curr != null){
                    
                    if(curr.getFactura().getID().equals(cod)){
                        
                        ante.setSig(curr.getSig());
                        ante.getSig().setSig(ante);
                        break;
                        
                    }else{
                        
                        ante = curr;
                        curr = curr.getSig();
                        
                    }

                }
 
            }

        }
 
    }   
        
        
    
    
    
    
    
    
}

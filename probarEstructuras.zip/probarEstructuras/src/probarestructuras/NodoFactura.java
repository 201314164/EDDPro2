/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoFactura {
    
    private factura factura;
    
    private NodoFactura sig;
    private NodoFactura ant;

    public NodoFactura() {
    
        this.factura = new factura();
    
        this.sig = null;
        this.ant = null;
    
    }

    public NodoFactura(factura factura) {
        
        this.factura = factura;
        
        this.sig = null;
        this.ant = null;
        
    }

    /**
     * @return the factura
     */
    public factura getFactura() {
        return factura;
    }

    /**
     * @param factura the factura to set
     */
    public void setFactura(factura factura) {
        this.factura = factura;
    }

    /**
     * @return the der
     */
    public NodoFactura getSig() {
        return sig;
    }

    /**
     * @param der the der to set
     */
    public void setSig(NodoFactura sig) {
        this.sig = sig;
    }

    /**
     * @return the izq
     */
    public NodoFactura getAnt() {
        return ant;
    }

    /**
     * @param izq the izq to set
     */
    public void setAnt(NodoFactura ant) {
        this.ant = ant;
    }
    
    
    
    
    
    
    
}

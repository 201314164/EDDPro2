/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoAdy {
    
    private destino destino;
    
    private int peso;
    private int tiempo;
    private int costo;
    
    private listaSimple camino;
    
    private listaAdy adyacentes;
    
    private NodoAdy sig;
    
    private NodoAdy der;

    public NodoAdy() {
        
        this.destino = new destino();
        this.peso = Integer.MAX_VALUE;
        
        this.camino = new listaSimple();
        this.adyacentes = new listaAdy();
        
        this.sig = null;
        this.der = null;
        
    }

    public NodoAdy(destino destino) {
        
        this.destino = destino;
        this.peso = Integer.MAX_VALUE;
        
        this.camino = new listaSimple();
        this.adyacentes = new listaAdy();
        
        this.sig = null;
        this.der = null;
        
    }
    
    public void niuAdyacencia(NodoAdy destino, int peso , ruta ruta){
        

    this.setCosto( ruta.getValor());
    this.setTiempo( ruta.getTiempo());
        
    this.adyacentes.insertar(destino, peso, ruta);
        
        
    }
    
    
    public void niuAdyacencia(NodoAdy destino, int peso ){
        

    //this.setCosto(this.getCosto() + ruta.getValor());
    //this.setTiempo(this.getTiempo() + ruta.getTiempo());
        
        this.adyacentes.insertar(destino, peso);
        
        
    }
    
    
    
    

    /**
     * @return the sig
     */
    public NodoAdy getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoAdy sig) {
        this.sig = sig;
    }

    /**
     * @return the destino
     */
    public destino getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(destino destino) {
        this.destino = destino;
    }

    /**
     * @return the peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(int peso) {
        this.peso = peso;
    }

    /**
     * @return the camino
     */
    public listaSimple getCamino() {
        return camino;
    }

    /**
     * @param camino the camino to set
     */
    public void setCamino(listaSimple camino) {
        this.camino = camino;
    }

    /**
     * @return the adyacentes
     */
    public listaAdy getAdyacentes() {
        return adyacentes;
    }

    /**
     * @param adyacentes the adyacentes to set
     */
    public void setAdyacentes(listaAdy adyacentes) {
        this.adyacentes = adyacentes;
    }

    /**
     * @return the tiempo
     */
    public int getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    /**
     * @return the costo
     */
    public int getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(int costo) {
        this.costo = costo;
    }
    
    
    
    
    
    
    
    
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 *
 * @author gios
 */
public class Grafo {
    
    String graf = "";
    private listaSimple nodos;
    Dijkstra djk = new Dijkstra();

    public Grafo() {
    
        this.nodos = new listaSimple();
        
    }
    

    public Grafo(listaSimple nodos) {
        this.nodos = nodos;
    }

    /**
     * @return the nodos
     */
    public listaSimple getNodos() {
        return nodos;
    }

    /**
     * @param nodos the nodos to set
     */
    public void setNodos(listaSimple nodos) {
        this.nodos = nodos;
    }
    
    
    public void addNodo(NodoAdy nodo){
        
        NodoAdy copia = new NodoAdy();
        copia.setAdyacentes(nodo.getAdyacentes());
        copia.setCamino(nodo.getCamino());
        copia.setDestino(nodo.getDestino());
        copia.setPeso(nodo.getPeso());
        
        this.nodos.insertar(copia);
        
        
        
    }
    
    public void addNodo2(NodoAdy nodo){
        
        
        
        this.nodos.insertar(nodo);
        
        
        
    }
    
    
    
    public void deMatriz(ListaCab cab, ListaLat lat){
        
        if(cab.cabeza != null && lat.cabeza != null){
            NodoLat temp = lat.cabeza;
            while(temp != null){
                
                NodoAdy nodo = new NodoAdy(temp.getDestino());
                
                addNodo2(nodo);
                
                temp = temp.getSig();
            }
            
            NodoLat temp2 = lat.cabeza;
            while(temp2 != null){
                
                NodoMA temp3 = temp2.getFila().cabeza;
                while(temp3 != null){
                    
                    if(temp3.isConex()){
                    
                        if(this.nodos.buscar(temp3.getRuta().getInicio()) && this.nodos.buscar(temp3.getRuta().getFin())){
                            
                            NodoAdy nodoI = this.nodos.obtener(temp3.getRuta().getInicio());
                            NodoAdy nodoF = this.nodos.obtener(temp3.getRuta().getFin());
                            
                            nodoI.niuAdyacencia(nodoF, temp3.getRuta().getTiempo() * temp3.getRuta().getValor(), temp3.getRuta());

                        }

                    }

                    temp3 = temp3.getDer();
                }

                temp2 = temp2.getSig();
            }
  
        }
        
    }
    
    public NodoRuta mejorRuta(String codigoI,String codigoF, Grafo grafo){
        
        return mejorRuta(codigoI, codigoF, grafo, this.nodos);
        
    }

    private NodoRuta mejorRuta(String codigoI, String codigoF, Grafo grafo, listaSimple nodos) {
        
        if(nodos.cabeza != null){
            
            if(nodos.buscar(codigoI)){
                
                NodoAdy nodoI = nodos.obtener(codigoI);
                
                Grafo niuGraf = djk.caminoMasCorto(grafo, nodoI);
                
                
                NodoAdy dest = niuGraf.getNodos().obtener(codigoF);
                
                
                
                    listaDestinos ruta = new listaDestinos();
                    int tiempo = dest.getTiempo();
                    int valor = dest.getCosto();
                    
                    
                    
                    
                    //System.out.println(dest.getDestino().getNombre());
                    
                    NodoAdy temp2 = dest.getCamino().cabeza;
                    while(temp2 != null){
               
                        //System.out.print("(" + temp2.getDestino().getNombre() + " - " + temp2.getPeso() + ")" + " -> ");
                        
                        
                        ruta.insertar(temp2.getDestino());
                                
                        temp2 = temp2.getSig();
                        
                    }
                    
                    ruta.insertar(dest.getDestino());
                
                    NodoRuta nodo = new NodoRuta(ruta, valor, tiempo);
                    nodo.setTiempo(tiempo);
                    nodo.setCosto(valor);
                    return nodo;
                
                
            }

        }
        
        return null;
  
    }
    
    
    public listaRutas posiblesRutas(String codigoI, String codigoF, Grafo grafo){
        
        return posiblesRutas(codigoI, codigoF, grafo, this.nodos);
        
    }

    private listaRutas posiblesRutas(String codigoI, String codigoF, Grafo grafo, listaSimple nodos) {
        
        listaRutas pos = null;
        
        if(nodos.cabeza != null){
            
            if(nodos.buscar(codigoI) && nodos.buscar(codigoF)){
                
                NodoAdy nodoI = nodos.obtener(codigoI);
                NodoAdy nodoF = nodos.obtener(codigoF);
                
                pos = djk.posiblesRutas(nodoI, nodoF);
                
                pos.setMejor( mejorRuta(codigoI, codigoF, grafo));
  
            }

        }
        
        return pos;
    }
    
    
    
    
    public void graficar(Matriz mat){
        
        graf = "graph grafo{\nrankdir=LR;\nconcentrate=true;";
        
        if(mat.cabeceras.cabeza != null && mat.laterales.cabeza != null){
        
            NodoLat temp = mat.laterales.cabeza;
            while(temp != null){
                
                NodoMA temp2 = temp.getFila().cabeza;
                while(temp2 != null){
                    
                    if(temp2.isConex()){
                        
                        if(mat.laterales.buscar(temp2.getRuta().getInicio()) && mat.laterales.buscar(temp2.getRuta().getFin())){
                            NodoLat nodoI = mat.laterales.obtener(temp2.getRuta().getInicio());
                            NodoLat NodoF = mat.laterales.obtener(temp2.getRuta().getFin());
                            
                            graf += "\n"+temp2.getRuta().getInicio() + "[label = \""+ nodoI.getDestino().getNombre() +"\"]";
                            graf += "\n"+temp2.getRuta().getInicio() + " -- "+temp2.getRuta().getFin();
                            
                        }
                        
                        
                        
                    }
                    
                    
                    temp2 = temp2.getDer();
                }
                
                
                temp = temp.getSig();
            }
            
            
            
        }
        graf += "\n}";
        
        genDot(graf , "GrafoCompleto","sfdp");
        
            
    }
    
    
    private void genDot(String cod, String nombre , String tipo){
        
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+""+nombre+".dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { tipo , "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/"+nombre+".dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/"+nombre+".png" };
                Process proc = new ProcessBuilder(command).start();
                //System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
    
    }
    
    
    public void graficarRuta(NodoRuta ruta){
        
        graf = "graph grafoRuta{\nrankdir=LR;\nconcentrate=true;";
        
        if(ruta.getRutas().cabeza != null){
            
            NodoDestino temp = ruta.getRutas().cabeza;
            while (temp != null){
                
                graf += "\n"+temp.getDestino().getCodigo() + "[label = \""+ temp.getDestino().getNombre() +"\"];";
                
                if(temp.getSig() != null){
                    
                    graf += "\n"+temp.getDestino().getCodigo() + " -- "+temp.getSig().getDestino().getCodigo() + ";";
                    
                }
                
                temp = temp.getSig();
            }
            
            
            
            
        }
        
        graf += "\n}";
        
        genDot(graf, "GrafoRuta","dot");
        
        
    }
    
    
    public void graficarListaRutas(listaRutas rutas){
        
        graf = "graph grafoRutas{\nrankdir=LR;\nconcentrate=true;";
        
        if(rutas.cabeza != null){
            
            NodoRuta temp = rutas.cabeza;
            while (temp != null){
                
                NodoDestino temp2 = temp.getRutas().cabeza;
                
                while (temp2 != null){
                
                    graf += "\n"+temp2.getDestino().getCodigo() + "[label = \""+ temp2.getDestino().getNombre() +"\"];";
                
                    
                
                    temp2 = temp2.getSig();
                }
                
                
                temp = temp.getSig();
                
            }
            
            
            NodoRuta temp3 = rutas.cabeza;
            while (temp3 != null){
                
                NodoDestino temp4 = temp3.getRutas().cabeza;
                
                while (temp4 != null){
                
                    
                
                    if(temp4.getSig() != null){
                    
                        graf += "\n"+temp4.getDestino().getCodigo() + " -- "+temp4.getSig().getDestino().getCodigo()+";";
                    
                    }
                
                    temp4 = temp4.getSig();
                }
                
                
                temp3 = temp3.getSig();
                
            }
            
            
        }
        
        graf += "\n}";
        
        genDot(graf, "GrafoRutas","sfdp");
        
        
        
    }
    
    
  
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class Grafo {
    
    private listaSimple nodos;
    Dijkstra djk = new Dijkstra();

    public Grafo() {
    
        this.nodos = new listaSimple();
        
    }
    

    public Grafo(listaSimple nodos) {
        this.nodos = nodos;
    }

    /**
     * @return the nodos
     */
    public listaSimple getNodos() {
        return nodos;
    }

    /**
     * @param nodos the nodos to set
     */
    public void setNodos(listaSimple nodos) {
        this.nodos = nodos;
    }
    
    
    public void addNodo(NodoAdy nodo){
        
        NodoAdy copia = new NodoAdy();
        copia.setAdyacentes(nodo.getAdyacentes());
        copia.setCamino(nodo.getCamino());
        copia.setDestino(nodo.getDestino());
        copia.setPeso(nodo.getPeso());
        
        this.nodos.insertar(copia);
        
        
        
    }
    
    public void addNodo2(NodoAdy nodo){
        
        
        
        this.nodos.insertar(nodo);
        
        
        
    }
    
    
    
    public void deMatriz(ListaCab cab, ListaLat lat){
        
        if(cab.cabeza != null && lat.cabeza != null){
            NodoLat temp = lat.cabeza;
            while(temp != null){
                
                NodoAdy nodo = new NodoAdy(temp.getDestino());
                addNodo2(nodo);
                
                temp = temp.getSig();
            }
            
            NodoLat temp2 = lat.cabeza;
            while(temp2 != null){
                
                NodoMA temp3 = temp2.getFila().cabeza;
                while(temp3 != null){
                    
                    if(temp3.isConex()){
                    
                        if(this.nodos.buscar(temp3.getRuta().getInicio()) && this.nodos.buscar(temp3.getRuta().getFin())){
                            
                            NodoAdy nodoI = this.nodos.obtener(temp3.getRuta().getInicio());
                            NodoAdy nodoF = this.nodos.obtener(temp3.getRuta().getFin());
                            
                            nodoI.niuAdyacencia(nodoF, temp3.getRuta().getTiempo() * temp3.getRuta().getValor());

                        }

                    }

                    temp3 = temp3.getDer();
                }

                temp2 = temp2.getSig();
            }
  
        }
        
    }
    
    public NodoRuta mejorRuta(String codigoI,String codigoF, Grafo grafo){
        
        return mejorRuta(codigoI, codigoF, grafo, this.nodos);
        
    }

    private NodoRuta mejorRuta(String codigoI, String codigoF, Grafo grafo, listaSimple nodos) {
        
        if(nodos.cabeza != null){
            
            if(nodos.buscar(codigoI)){
                
                NodoAdy nodoI = nodos.obtener(codigoI);
                
                Grafo niuGraf = djk.caminoMasCorto(grafo, nodoI);
                
                
                
                
                
                NodoAdy temp = niuGraf.getNodos().cabeza;
                
                while(temp != null){
                    
                    listaDestinos ruta = new listaDestinos();
                    
                    System.out.println(temp.getDestino().getNombre());
                    
                    NodoAdy temp2 = temp.getCamino().cabeza;
                    while(temp2 != null){
               
                        System.out.print("(" + temp2.getDestino().getNombre() + " - " + temp2.getPeso() + ")" + " -> ");
                        
                        ruta.insertar(temp2.getDestino());
                                
                        temp2 = temp2.getSig();
                        
                    }
                    
                    System.out.println("\n");
                    temp = temp.getSig();
                
                }
                
                
                
                
            }

        }
  
    }
    
    
    
    
  
}

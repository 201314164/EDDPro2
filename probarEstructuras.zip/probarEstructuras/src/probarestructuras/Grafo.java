/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class Grafo {
    
    private listaSimple nodos;

    public Grafo() {
    
        this.nodos = new listaSimple();
        
    }
    

    public Grafo(listaSimple nodos) {
        this.nodos = nodos;
    }

    /**
     * @return the nodos
     */
    public listaSimple getNodos() {
        return nodos;
    }

    /**
     * @param nodos the nodos to set
     */
    public void setNodos(listaSimple nodos) {
        this.nodos = nodos;
    }
    
    
    public void addNodo(NodoAdy nodo){
        
        NodoAdy copia = new NodoAdy();
        copia.setAdyacentes(nodo.getAdyacentes());
        copia.setCamino(nodo.getCamino());
        copia.setDestino(nodo.getDestino());
        copia.setPeso(nodo.getPeso());
        
        this.nodos.insertar(copia);
        
        
        
    }
    
    public void addNodo2(NodoAdy nodo){
        
        
        
        this.nodos.insertar(nodo);
        
        
        
    }
    
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class listaDestinos {
    
    NodoDestino cabeza;
    NodoDestino fin;

    public listaDestinos() {
    
        this.cabeza = null;
        this.fin = null;
    
    }
    
    public void insertar(destino newDes){
        
        insertar(newDes, this.cabeza,this.fin);
        
    }

    private void insertar(destino newDes,  NodoDestino hed, NodoDestino teil) {
        
        if (hed == null){
            
            NodoDestino niu = new NodoDestino(newDes);
            cabeza = niu;
            fin = niu;
            
        }else{
            
            if(teil != null){
                
                NodoDestino niu = new NodoDestino(newDes);
                fin.setSig(niu);
                fin = niu;
  
            }
 
        }
        
        
        
        
    }
    
    
    public void eliminar(String cod){
        
        eliminar(cod, this.cabeza,this.fin);
        
        
    }
    
    private void eliminar(String cod, NodoDestino hed, NodoDestino teil){
        
        if(hed != null){
            
            
            if(hed == teil){
                cabeza = null;
                fin = null;
            }else if(cabeza.getDestino().getCodigo().equals(cod)){
                
                NodoDestino temp = cabeza;
                cabeza = cabeza.getSig();
                temp.setSig(null);
 
            }else if(fin.getDestino().getCodigo().equals(cod)){
                
                NodoDestino temp = cabeza;
                while(temp.getSig() != fin){
                    
                    temp = temp.getSig();
                    
                }
                
                temp.setSig(null);
                fin = temp;
  
            }else{
                
                NodoDestino ante = cabeza;
                NodoDestino curr = cabeza.getSig();
                while(curr != null){
                    
                    if(curr.getDestino().getCodigo().equals(cod)){
                        
                        ante.setSig(curr.getSig());
                        
                    }else{
                        
                        ante = curr;
                        curr = curr.getSig();
                        
                    }

                }
 
            }

        }
 
    }
    

    
    
    
    
}

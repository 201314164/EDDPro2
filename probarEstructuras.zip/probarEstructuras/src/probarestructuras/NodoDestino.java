/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoDestino {
    
    private destino destino;
    
    private NodoDestino sig;

    public NodoDestino() {
    
        this.destino = new destino();
        
        this.sig = null;
    
    }

    public NodoDestino(destino destino) {
        this.destino = destino;
        this.sig = null;
    }

    /**
     * @return the destino
     */
    public destino getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(destino destino) {
        this.destino = destino;
    }

    /**
     * @return the sig
     */
    public NodoDestino getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoDestino sig) {
        this.sig = sig;
    }
    
    
    
    
    
}

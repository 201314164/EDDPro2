/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoLat {
    
    private destino destino;
    
    private fila fila;
    
    private NodoLat sig;
    

    public NodoLat() {
    
    this.destino = new destino();
    
    this.fila = new fila();
    
    this.sig = null;
    
    }

    public NodoLat(destino destino) {
        
        this.destino = destino;
        this.fila = new fila();
        this.sig = null;
    
    }

    /**
     * @return the destino
     */
    public destino getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(destino destino) {
        this.destino = destino;
    }

    /**
     * @return the fila
     */
    public fila getFila() {
        return fila;
    }

    /**
     * @param fila the fila to set
     */
    public void setFila(fila fila) {
        this.fila = fila;
    }

    /**
     * @return the sig
     */
    public NodoLat getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoLat sig) {
        this.sig = sig;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}

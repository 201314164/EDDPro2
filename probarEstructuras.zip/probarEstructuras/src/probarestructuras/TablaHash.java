/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import static java.lang.Math.sqrt;
import java.util.ArrayList;



/**
 *
 * @author gios
 */
public class TablaHash {
    
    private int sais = 43;
    int elementos;
    
    String graf = "";
    String ruta = "";
    
    private NodoHash[] tabla;

    public TablaHash() {
        
        tabla = new NodoHash[sais];
        elementos = 0;
        graf = "";
    }
    
    private int hash(int k){
        System.out.println(k);
        System.out.println(k % sais);
        return (k % sais);
        
        
    }
    
    public void insertar(NodoHash niu){
        
        int llave = hash(niu.getReservacion());
        
        if(getTabla()[llave] == null){
            
            getTabla()[llave] = niu;
            elementos++;
            System.out.println("Se inserto en ->" + llave);
            
        }else{
            getTabla()[llave].setConflicto(true);
            int colision = llave + 2;
            if (colision >= this.sais){
                    colision = 0;
                }
            getTabla()[llave].setPosConflic(colision);
            
            boolean flag = false;
            
            
            while (flag == false){
                if(getTabla()[colision] == null){
                    flag = true;
                    break;
                }else{
                    getTabla()[colision].setConflicto(true); 
                    getTabla()[colision].setPosConflic(colision + 2);
                    //System.out.println("¡Colision! buscando en ->" + (colision+2));
                }
                
                colision = colision + 2;
                if (colision >= this.sais){
                    colision = 0;
                }

            }
            
            getTabla()[colision] = niu;
            elementos++;
            System.out.println("¡Colision! Se inserto en ->" + colision);
            

        }
        
        if(chkCarga(this.sais, elementos))
            reHash();
        

    }

    private boolean chkCarga(int sais, int elementos) {
    
        //System.out.println(sais);
        //System.out.println(elementos);
        double factorCarga = (elementos*100/sais);
        System.out.println(factorCarga);
        if(factorCarga > 50){
            
            return true;
        }else{
            return false;
        }
    
    }

    private void reHash() {
        
        NodoHash[] temp = getTabla().clone();
        
        this.sais = nextPrime(sais);
        this.elementos = 0;
        this.setTabla(new NodoHash[sais]);
        
        for(int i = 0; i < temp.length ; i++){
            
            if(temp[i] != null)
                insertar(temp[i]);
            
        }
        
        
        
    }
    
    public int nextPrime(int input){
        int counter;
        input++;   
        while(true){
            counter = 0;
            for(int i = 2; i <= sqrt(input); i ++){
                if(input % i == 0)  counter++;
            }
            if(counter == 0)
                return input;
            else{
                input++;
                continue;
            }
        }
    }

    /**
     * @return the tabla
     */
    public NodoHash[] getTabla() {
        return tabla;
    }

    /**
     * @param tabla the tabla to set
     */
    public void setTabla(NodoHash[] tabla) {
        this.tabla = tabla;
    }
    
    
    public NodoHash buscar(int reserv){
        
        return buscar(reserv, this.tabla);
        
    }

    private NodoHash buscar(int cod, NodoHash[] tabla) {

        int llave = hash(cod);
        
        if(tabla[llave].getReservacion() == cod){
            
            return tabla[llave];

        }else{
            
            if(tabla[llave].isConflicto()){
                boolean flag = false;
                int conflicto = llave + 2;
                
                while(flag == false){
                    
                    if(tabla[conflicto].getReservacion() == cod){
                        
                        flag = true;
                        return tabla[conflicto];
                    
                    }
                    
                   conflicto = conflicto +2; 
                    
                }
  
            }

        }
        
        return null;

    }
    
    public void cancelar(int reserv){
        
        cancelar(reserv, this.tabla);
        
    }

    private void cancelar(int cod, NodoHash[] tabla) {

        int llave = hash(cod);
        
        if(tabla[llave].getReservacion() == cod){
            
            tabla[llave].setEstado(false);

        }else{
            
            if(tabla[llave].isConflicto()){
                boolean flag = false;
                int conflicto = llave + 2;
                
                while(flag == false){
                    
                    if(tabla[conflicto].getReservacion() == cod){
                        
                        tabla[conflicto].setEstado(false);
                        flag = true;
                        return;
                    
                    }
                    
                   conflicto = conflicto +2; 
                    
                }
  
            }

        }
        
        

    }
    
    public void graficar(NodoHash[] tabla){
        ruta = "";
        graf = "digraph structs { \nrankdir=LR;\nfontsize = 10;\nnode [shape=record]; ";
        for(int i = 0; i < tabla.length; i++){
            
            if(i == 0){
                if(tabla[i] == null){
                    graf += "\nHASH[label=\"<"+i+">" +(i+1)+" Vacio "
                    ;
                }else{
                    graf += "\nHASH[label=\"<"+i+">" +(i+1)+" -#Reservacion: "+ tabla[i].getReservacion() +
                            "\\n -Cliente: " + tabla[i].getCliente() +
                            "\\n -Costo: " + tabla[i].getCosto() +
                            "\\n -Duracion: " + tabla[i].getTiempo()
                            ; 
                    
                    
                NodoDestino rut = tabla[i].getRuta().getRutas().cabeza;
                ruta += "\nHASH:"+i + " -> " + rut.getDestino().getCodigo() +""+i+";";
                while(rut != null){
                    
                    ruta += "\n"+rut.getDestino().getCodigo() +""+i+"[label=\""+rut.getDestino().getNombre()+"\"];";
                    
                    if(rut.getSig() != null){
                        
                        ruta += "\n"+rut.getDestino().getCodigo() +""+i+ " -> " + rut.getSig().getDestino().getCodigo() +""+i+";";
                        
                    }
                    
                    
                    rut = rut.getSig();
                }
                
                }
            }else{
            
            if(tabla[i] == null){
                
                graf += "|<"+i+">" +(i+1)+" Vacio ";
                
            }else{
                
                graf += "|<"+i+">" +(i+1)+" -#Reservacion: "+ tabla[i].getReservacion() +
                            "\\n -Cliente: " + tabla[i].getCliente() +
                            "\\n -Costo: " + tabla[i].getCosto() +
                            "\\n -Duracion: " + tabla[i].getTiempo()
                            ; 
                
                NodoDestino rut = tabla[i].getRuta().getRutas().cabeza;
                ruta += "\nHASH:"+i + " -> " + rut.getDestino().getCodigo() +""+i+";";
                while(rut != null){
                    
                    ruta += "\n"+rut.getDestino().getCodigo() +""+i+"[label=\""+rut.getDestino().getNombre()+"\"];";
                    
                    if(rut.getSig() != null){
                        
                        ruta += "\n"+rut.getDestino().getCodigo() +""+i+ " -> " + rut.getSig().getDestino().getCodigo() +""+i+";";
                        
                    }
                    
                    
                    rut = rut.getSig();
                }
                
            }
            }
            
        }
        graf += "\"];";
        graf += ruta;
        graf += "\n}";
        
        
        genDot(graf);
        
    }
    
    
    private void genDot(String cod){
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+"Hash.dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { "dot", "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/Hash.dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/Hash.png" };
                Process proc = new ProcessBuilder(command).start();
                System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
        
        
        
        
        
    }
    
    
}

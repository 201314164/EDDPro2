/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author gios
 */
public class NodoBlock {
    
    private String corre;
    private String nombre;
    private String hash;
    private NodoFactura factura;
    
    private String hashAnt;

    private NodoBlock sig;
    private NodoBlock ant;
    
    public NodoBlock() {
    
        corre = "";
        nombre = "";
        hash = "";
        factura = null;
        
        hashAnt = "";
        
        sig = null;
        ant = null;
        
    
    }

    public NodoBlock(String corre, String nombre, NodoFactura factura) throws NoSuchAlgorithmException {
        this.corre = corre;
        this.nombre = nombre;
        this.hash = hash(corre,factura.getFactura().getID());
        this.factura = factura;
        this.hashAnt = "";
        this.sig = sig;
        this.ant = ant;
    }

    private String hash(String corre, String id) throws NoSuchAlgorithmException {
        
        
        String text = id + corre;
        
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(text.getBytes(StandardCharsets.UTF_8));
        
        
        
            StringBuffer hexString = new StringBuffer();
             for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
             
             System.out.println(hexString.toString().substring(0, 9));
             
            return hexString.toString().substring(0, 9);
        
        
       
        
    }

    /**
     * @return the corre
     */
    public String getCorre() {
        return corre;
    }

    /**
     * @param corre the corre to set
     */
    public void setCorre(String corre) {
        this.corre = corre;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the hash
     */
    public String getHash() {
        return hash;
    }

    /**
     * @param hash the hash to set
     */
    public void setHash(String hash) {
        this.hash = hash;
    }

    /**
     * @return the factura
     */
    public NodoFactura getFactura() {
        return factura;
    }

    /**
     * @param factura the factura to set
     */
    public void setFactura(NodoFactura factura) {
        this.factura = factura;
    }

    /**
     * @return the hashAnt
     */
    public String getHashAnt() {
        return hashAnt;
    }

    /**
     * @param hashAnt the hashAnt to set
     */
    public void setHashAnt(String hashAnt) {
        this.hashAnt = hashAnt;
    }

    /**
     * @return the sig
     */
    public NodoBlock getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoBlock sig) {
        this.sig = sig;
    }

    /**
     * @return the ant
     */
    public NodoBlock getAnt() {
        return ant;
    }

    /**
     * @param ant the ant to set
     */
    public void setAnt(NodoBlock ant) {
        this.ant = ant;
    }
    
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.util.Random;

/**
 *
 * @author gios
 */
public class NodoHash {
    
    private int costo;
    private int tiempo;
    private int reservacion; 
    private String cliente;
    private String codCliente;
    private boolean estado;
    
    private boolean conflicto;
    private int posConflic;
    
    private NodoRuta ruta;
    
    private NodoHash sig;

    public NodoHash() {
    
        this.costo = 0;
        this.tiempo = 0;
        this.reservacion = numRand();
        this.cliente = "";
        this.codCliente = "";
        this.estado = true;
        
        this.conflicto = false;
        this.posConflic = 0;
        
        this.ruta = new NodoRuta();
        
        this.sig = null;
    
    
    }

    public NodoHash(int costo, int tiempo, String cliente, String codCliente, NodoRuta ruta) {
        
        this.costo = costo;
        this.tiempo = tiempo;
        this.reservacion = numRand();
        this.cliente = cliente;
        this.codCliente = codCliente;
        this.estado = true;
        
        this.conflicto = false;
        this.posConflic = 0;
        
        this.ruta = ruta;
        
        this.sig = null;
        
    }
    
    
    private int numRand(){
        
        Random rand = new Random();
        return rand.nextInt(Integer.MAX_VALUE) + 1;
        
    }

    /**
     * @return the costo
     */
    public int getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(int costo) {
        this.costo = costo;
    }

    /**
     * @return the tiempo
     */
    public int getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    /**
     * @return the reservacion
     */
    public int getReservacion() {
        return reservacion;
    }

    /**
     * @param reservacion the reservacion to set
     */
    public void setReservacion(int reservacion) {
        this.reservacion = reservacion;
    }

    /**
     * @return the cliente
     */
    public String getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the ruta
     */
    public NodoRuta getRuta() {
        return ruta;
    }

    /**
     * @param ruta the ruta to set
     */
    public void setRuta(NodoRuta ruta) {
        this.ruta = ruta;
    }

    /**
     * @return the conflicto
     */
    public boolean isConflicto() {
        return conflicto;
    }

    /**
     * @param conflicto the conflicto to set
     */
    public void setConflicto(boolean conflicto) {
        this.conflicto = conflicto;
    }

    /**
     * @return the posConflic
     */
    public int getPosConflic() {
        return posConflic;
    }

    /**
     * @param posConflic the posConflic to set
     */
    public void setPosConflic(int posConflic) {
        this.posConflic = posConflic;
    }

    /**
     * @return the estado
     */
    public boolean isEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * @return the codCliente
     */
    public String getCodCliente() {
        return codCliente;
    }

    /**
     * @param codCliente the codCliente to set
     */
    public void setCodCliente(String codCliente) {
        this.codCliente = codCliente;
    }

    /**
     * @return the sig
     */
    public NodoHash getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoHash sig) {
        this.sig = sig;
    }
    
    
    
 
}

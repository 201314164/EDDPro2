/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author gios
 */
public class ProbarEstructuras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
                Scanner scan = new Scanner(System.in);

        /* Creating object of AVLTree */

        AVL avlt = new AVL(); 
        
        /*ListaCab cab = new ListaCab();
        
        cab.insertar(new destino("7710","Guatemala"));
        cab.insertar(new destino("7720","El Salvador"));
        cab.insertar(new destino("7740","Honduras"));
        cab.insertar(new destino("7700","Mexico"));
        cab.insertar(new destino("7730","Belice"));
        cab.insertar(new destino("7715","Cuba"));

        
        cab.graficar(cab.cabeza);
        
        ListaLat lat = new ListaLat();
        
        lat.insertar(new destino("7710","Guatemala"));
        lat.insertar(new destino("7720","El Salvador"));
        lat.insertar(new destino("7740","Honduras"));
        lat.insertar(new destino("7700","Mexico"));
        lat.insertar(new destino("7730","Belice"));
        lat.insertar(new destino("7715","Cuba"));
        
        lat.graficar(lat.cabeza);
       */
       
       Matriz mat = new Matriz();
       
       mat.insertar(new destino("7710","Guatemala"));
       mat.insertar(new destino("7720","El Salvador"));
       mat.insertar(new destino("7740","Honduras"));
       mat.insertar(new destino("7700","Mexico"));
       mat.insertar(new destino("7730","Belice"));
       mat.insertar(new destino("7715","Cuba"));
       
       //mat.cabeceras.graficar(mat.cabeceras.cabeza);
       //mat.laterales.graficar(mat.laterales.cabeza);
       
       mat.nuevaRuta("7700", "7715", "100", "45", true);
       
       
       
       mat.graficar(mat.cabeceras.cabeza, mat.laterales.cabeza);
       
       
       
       
        NodoAdy nodoA = new NodoAdy(new destino("7710","A"));
        NodoAdy nodoB = new NodoAdy(new destino("7720","B"));
        NodoAdy nodoC = new NodoAdy(new destino("7770","C"));
        NodoAdy nodoD = new NodoAdy(new destino("7740","D"));
        NodoAdy nodoE = new NodoAdy(new destino("7750","E"));
        NodoAdy nodoF = new NodoAdy(new destino("7790","F"));

       
       
        nodoA.niuAdyacencia(nodoB, 10);
        nodoA.niuAdyacencia(nodoC, 15);
 
        nodoB.niuAdyacencia(nodoD, 12);
        nodoB.niuAdyacencia(nodoF, 15);
 
        nodoC.niuAdyacencia(nodoE, 10);
 
        nodoD.niuAdyacencia(nodoE, 2);
        nodoD.niuAdyacencia(nodoF, 20);
 
        nodoF.niuAdyacencia(nodoE, 5);
       
       Grafo grafo = new Grafo();
       
       grafo.addNodo2(nodoA);
       grafo.addNodo2(nodoB);
       grafo.addNodo2(nodoC);
       grafo.addNodo2(nodoD);
       grafo.addNodo2(nodoE);
       grafo.addNodo2(nodoF);
       
       Dijkstra algoritmo = new Dijkstra();
       
       Grafo niugrafo = algoritmo.caminoMasCorto(grafo, nodoA);
       
       NodoAdy temp = niugrafo.getNodos().cabeza;
       while(temp != null){
           System.out.println(temp.getDestino().getNombre());
           NodoAdy temp2 = temp.getCamino().cabeza;
           while(temp2 != null){
               
               System.out.print("(" + temp2.getDestino().getNombre() + " - " + temp2.getPeso() + ")" + " -> ");
               temp2 = temp2.getSig();
           }
           System.out.println("\n");
           temp = temp.getSig();
       }
        
        
        int x = 1+1;
        

//        avlt.insertar(new usuario("50","****","Os"));     
//        avlt.insertar(new usuario("F","",""));    
//        avlt.insertar(new usuario("T","",""));      
//        avlt.insertar(new usuario("C","",""));
//        avlt.insertar(new usuario("N","",""));  
//        avlt.insertar(new usuario("S","",""));  
//        avlt.insertar(new usuario("Z","",""));  
//        avlt.insertar(new usuario("E","",""));  
//        avlt.insertar(new usuario("G","",""));  
//        avlt.insertar(new usuario("P","",""));  
//        avlt.insertar(new usuario("W","",""));  
//        avlt.insertar(new usuario("K","",""));  
//        avlt.insertar("45","","");  
//        avlt.insertar("55","","");  
//        avlt.insertar("10","","");  
        
//        avlt.borrar("S");
/*        
        
        if(avlt.buscar("50")){
            
        }
        NodoAVL mod = avlt.obtener("50");
        mod.getUsuario().setNombre("Oswaldo");
        
        avlt.graficar(avlt.raiz);
        
        List<usuario> usu = new ArrayList<>();
        
        usu = avlt.recorrer();
        
        usu.forEach(n -> System.out.println(n.getId()));
        
*/        

        System.out.println("AVLTree Tree Test\n");          

        char ch;

        /*  Perform tree operations  */

        do    

        {

            System.out.println("\nAVLTree Operations\n");

            System.out.println("1. insert ");

            System.out.println("2. search");

            System.out.println("3. Eliminar nodo");

            System.out.println("4. check empty");

            System.out.println("5. clear tree");

 

            int choice = scan.nextInt();            

            switch (choice)

            {

            case 1 : 

                System.out.println("Ingrese Id");
                
                String i = scan.next();
                System.out.println("Ingrese pass");
                String p = scan.next();
                System.out.println("Ingrese nombre");
                String n = scan.next();
                

                avlt.insertar(new usuario(i,p,n));     

                avlt.graficar(avlt.raiz);

                break;                          

            case 2 : 

                System.out.println("Enter integer element to search");

                System.out.println("Search result : "+ avlt.buscar( scan.next() ));

                break;                                          

            case 3 : 

                System.out.println("Ingrese Id");
                avlt.borrar(scan.next());
                avlt.graficar(avlt.raiz);

                break;     

            case 4 : 

                System.out.println("Empty status = "+ avlt.esVacio());

                break;     

            case 5 : 

                System.out.println("\nTree Cleared");

                avlt.eliminar();

                break;         

            default : 

                System.out.println("Wrong Entry \n ");

                break;   

            }

            /*  Display tree  */ 

//            System.out.print("\nPost order : ");
//
//            avlt.postorder();
//
//            System.out.print("\nPre order : ");
//
//            avlt.preorder();
//
//            System.out.print("\nIn order : ");
//
//            avlt.inorder();

 

            System.out.println("\nDo you want to continue (Type y or n) \n");

            ch = scan.next().charAt(0);                        

        } while (ch == 'Y'|| ch == 'y');               
        
        
        
        
        
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoMA {
    
    private ruta ruta;
    
    private boolean conex;
    
    private NodoMA arr;
    private NodoMA der;
    private NodoMA aba;
    private NodoMA izq;

    public NodoMA() {
        
        this.ruta = new ruta();
        
        this.conex = false;
        
        this.arr = null;
        this.aba = null;
        this.izq = null;
        this.der = null;
       
        
    }

    public NodoMA(ruta ruta) {
        this.ruta = ruta;
        
        this.conex = false;
        
        this.arr = null;
        this.der = null;
        this.aba = null;
        this.izq = null;
    }

    /**
     * @return the ruta
     */
    public ruta getRuta() {
        return ruta;
    }

    /**
     * @param ruta the ruta to set
     */
    public void setRuta(ruta ruta) {
        this.ruta = ruta;
    }

    /**
     * @return the arr
     */
    public NodoMA getArr() {
        return arr;
    }

    /**
     * @param arr the arr to set
     */
    public void setArr(NodoMA arr) {
        this.arr = arr;
    }

    /**
     * @return the der
     */
    public NodoMA getDer() {
        return der;
    }

    /**
     * @param der the der to set
     */
    public void setDer(NodoMA der) {
        this.der = der;
    }

    /**
     * @return the aba
     */
    public NodoMA getAba() {
        return aba;
    }

    /**
     * @param aba the aba to set
     */
    public void setAba(NodoMA aba) {
        this.aba = aba;
    }

    /**
     * @return the izq
     */
    public NodoMA getIzq() {
        return izq;
    }

    /**
     * @param izq the izq to set
     */
    public void setIzq(NodoMA izq) {
        this.izq = izq;
    }

    /**
     * @return the conex
     */
    public boolean isConex() {
        return conex;
    }

    /**
     * @param conex the conex to set
     */
    public void setConex(boolean conex) {
        this.conex = conex;
    }
    
    
    
    
    
}

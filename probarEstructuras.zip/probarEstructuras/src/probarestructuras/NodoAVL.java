/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gios
 */
public class NodoAVL {
    
    private usuario usuario;
    
    private NodoAVL izq;
    private NodoAVL der;
    
    private int altura;

    public NodoAVL() {
        
        usuario = new usuario();
        
        this.izq = null;
        this.der = null;
        this.altura = 0;
        
        
    }
    

    public NodoAVL(usuario newUsu) {
        
        this.usuario = newUsu;
        
        this.izq = null;
        this.der = null;
        this.altura = 0;
    }

    /**
     * @return the usuario
     */
    public usuario getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the izq
     */
    public NodoAVL getIzq() {
        return izq;
    }

    /**
     * @param izq the izq to set
     */
    public void setIzq(NodoAVL izq) {
        this.izq = izq;
    }

    /**
     * @return the der
     */
    public NodoAVL getDer() {
        return der;
    }

    /**
     * @param der the der to set
     */
    public void setDer(NodoAVL der) {
        this.der = der;
    }

    /**
     * @return the altura
     */
    public int getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(int altura) {
        this.altura = altura;
    }

    
    
    
    
    
    
}


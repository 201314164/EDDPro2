/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

/**
 *
 * @author gios
 */
public class factura {
    
    private String ID;
    private String fecha;
    private String hora;
    private int costo;
    private String nombre;
    private String codigo;
    private String vuelo;

    public factura() {
    
        this.ID = "";
        this.fecha = getFecha();
        this.hora = getHora();
        this.costo = 0;
        this.nombre = "";
        this.codigo = "";
        this.vuelo = "";

    }

    public factura(String ID, int costo, String nombre, String codigo, String vuelo) {
        this.ID = ID;
        this.fecha = getFechaAc();
        this.hora = getHoraAc();
        this.costo = costo;
        this.nombre = nombre;
        this.codigo = codigo;
        this.vuelo = vuelo;
    }
    
    

    private String getFechaAc() {
        
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");  
        return date.format(formatter);  
 
    }

    private String getHoraAc() {
        
        LocalTime time = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");  
        return time.format(formatter); 
        
    }

    /**
     * @return the ID
     */
    public String getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(String ID) {
        this.ID = ID;
    }

    /**
     * @return the fecha
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    /**
     * @return the hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * @return the costo
     */
    public int getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(int costo) {
        this.costo = costo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the vuelo
     */
    public String getVuelo() {
        return vuelo;
    }

    /**
     * @param vuelo the vuelo to set
     */
    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }
    
    
    
    
    
    
}

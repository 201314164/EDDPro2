/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 *
 * @author gios
 */
public class ListaLat {
    
    NodoLat cabeza;
    NodoLat fin;
    
    String graf = "";
    String mismoR = "";
    

    public ListaLat() {
    
    this.cabeza = null;
    this.fin = null;
    
    }
    
    
    public void insertar( destino newDes ){
        
        insertar(newDes, this.cabeza, this.fin);
        
    }
    
    private void insertar(destino newDes, NodoLat hed, NodoLat teil){

        if (hed == null){
            
            NodoLat nuevo = new NodoLat(newDes);
            cabeza = nuevo;
            fin = nuevo;
            
        }else{
            
            String id = newDes.getCodigo();

            if(id.compareTo(hed.getDestino().getCodigo()) < 0 || id.compareTo(hed.getDestino().getCodigo()) == 0 ){
                
                if(id.compareTo(hed.getDestino().getCodigo()) == 0){
                    //ya existe
                    
                }else{
                    //va antes de la cabeza
                    NodoLat nuevo = new NodoLat(newDes);
                    nuevo.setSig(cabeza);
                    cabeza = nuevo;
                
                }
                
            } else if(id.compareTo(teil.getDestino().getCodigo()) > 0 || id.compareTo(teil.getDestino().getCodigo()) == 0 ){
                
                if(id.compareTo(teil.getDestino().getCodigo()) == 0){
                    //ya existe
                 
                }else{
                    //va despues del final
                    NodoLat nuevo = new NodoLat(newDes);
                    fin.setSig(nuevo);
                    fin = nuevo;
 
                }

            }else{
                
                NodoLat ante = hed;
                NodoLat curr = hed.getSig();
                while(curr != fin && id.compareTo(curr.getDestino().getCodigo()) > 0){
                    ante = curr;
                    curr = curr.getSig();
               
                }
                
                if(id.compareTo(curr.getDestino().getCodigo()) == 0){
                    //Ya existe  
                }else{
                    
                    NodoLat nuevo = new NodoLat(newDes);
                    ante.setSig(nuevo);
                    nuevo.setSig(curr);
                    
   
                }
 
            }

        }
 
    }
    
    
    
    public boolean buscar(String cod){
        
        return buscar(cod, this.cabeza);
        
    }
    
    private boolean buscar(String cod, NodoLat hed){
       
        if (hed == null){
            return false;
        }else{
            
            NodoLat temp = hed;
            while(temp != null){
                if(temp.getDestino().getCodigo().equals(cod)){
                    return true;
                }else{
                    temp = temp.getSig();
                }
                
                
                
            }
            
            
        }
        return false;
        
        
        
        
    }
    
    
    
    
    public void graficar(NodoLat hed){
        
        graf = "digraph LECab{\nrankdir=TB;\nordering=\"out\"";
        if (hed != null){
            
            graf += " \nnode [shape=box;color=\"Purple\"];";
            recorreGraf(hed);
            //graf += "\n{rank =\"same\""+ mismoR +"}";
            mismoR = "";
            
        }else{
            
            graf+= " \nnode [shape=box;color=\"Purple\"];";
        }
        graf += "\n}";
        
        genDot(graf);
        
    }
    
    private void recorreGraf(NodoLat hed){
        
        if (hed != null){
            
            graf += "\n\"" + hed.getDestino().getCodigo() + "\"[label = \"" + hed.getDestino().getCodigo() +"\\n"+ hed.getDestino().getNombre() + "\"];";
            mismoR += " \""+hed.getDestino().getCodigo()+"\";";
            
            if(hed.getSig() != null){
                
                graf += "\n\"" + hed.getDestino().getCodigo() + "\" -> \"" + hed.getSig().getDestino().getCodigo() + "\"[color=\"Purple\" ];" ;
                recorreGraf(hed.getSig());
                
            }
            
        }
        
        
    }
    
    private void genDot(String cod){
        
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+"Lat.dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { "dot", "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/Lat.dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/Lat.png" };
                Process proc = new ProcessBuilder(command).start();
                //System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
        
        
        
        
    }
    
    
    
    
    
}

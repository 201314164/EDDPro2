/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 *
 * @author gios
 */
public class BlockChain {
    
    NodoBlock cabeza;
    NodoBlock fin;
    String graf = "";
    String mismoR = "";
    
    public BlockChain() {
    
        this.cabeza = null;
        this.fin  = null;
    
    
    }
    
    
    public void insertar(NodoBlock niuBlo){
        
        
        insertar(niuBlo, this.cabeza);
        
        
    }

    private void insertar(NodoBlock niuBlo, NodoBlock hed) {
    
        if(hed == null){
            
            cabeza = niuBlo;
            fin = niuBlo;
            
        }else{
            
            
            if(fin != null){
                
                fin.setSig(niuBlo);
                niuBlo.setAnt(fin);
                niuBlo.setHashAnt(fin.getHash());
                fin = niuBlo;
                
                
            }
            
            
            
            
        }
        
        
        
        
    }
    
    public boolean Comprobar(NodoBlock loc, NodoBlock serv){
        
        NodoBlock temp1 = loc;
        NodoBlock temp2 = serv;
        while(temp2 != null){
            
            if(temp1.getHash().equals(temp2.getHash())){
                temp1 = temp1.getSig();
                temp2 = temp2.getSig();
                
            }else{
                
                return false;
                
            }
            
            
            
            
        }
        
        return true;
        
    }
    
    
    
    public void graficar(NodoBlock hed){
        
                graf = "digraph BC{\nrankdir=TB;\nordering=\"out\"";
        if (hed != null){
            
            graf += " \nnode [shape=box;color=\"Purple\"];";
            recorreGraf(hed);
            graf += "\n{rank =\"same\""+ mismoR +"}";
            mismoR = "";
            
        }else{
            
            graf+= " \nnode [shape=box;color=\"Purple\"];";
        }
        graf += "\n}";
        
        genDot(graf);
        
        
        
    }
    
        private void recorreGraf(NodoBlock hed){
        
        if (hed != null){
            
            graf += "\n\""+ hed.getCorre()+"\"[label=\" -#Chain: "+ hed.getCorre() +
                            "\\n -Bloque: " + hed.getNombre() +
                            "\\n -Hash: " + hed.getHash() +
                            "\\n -HashAnterior: " + hed.getHashAnt()+"\"];"
                            ; 
            
            graf += "\n\""+hed.getFactura().getFactura().getID()+"\" [label=\" :#ID:" + hed.getFactura().getFactura().getID()+
                                            "\\n -Fecha: " + hed.getFactura().getFactura().getFecha() +
                                            "\\n -Hora: " + hed.getFactura().getFactura().getHora() +
                                            "\\n -Cliente: " + hed.getFactura().getFactura().getNombre() +
                                            "\\n -Codigo: " + hed.getFactura().getFactura().getID() +
                                            "\\n -Vuelo: " + hed.getFactura().getFactura().getVuelo() +"\"];" 
                                            ;
            graf+= "\n\"" + hed.getCorre()+"\" -> \""+ hed.getFactura().getFactura().getID()+"\";";
            
            mismoR += " \""+hed.getCorre()+"\";";
            
            if(hed.getSig() != null){
                
                graf += "\n\"" + hed.getCorre() + "\" -> \"" + hed.getSig().getCorre() + "\"[color=\"Purple\" ];" ;
                recorreGraf(hed.getSig());
                
            }
            
        }
        
        
    }
    
    private void genDot(String cod){
        
        String ubica = "/home/gios/NetBeansProjects/probarEstructuras/";
        
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ubica+"BCHAIN.dot"), "utf-8"));
            writer.write(cod);
        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();
                String[] command = { "dot", "-Tpng", "/home/gios/NetBeansProjects/probarEstructuras/BCHAIN.dot","-o" ,"/home/gios/NetBeansProjects/probarEstructuras/BCHAIN.png" };
                Process proc = new ProcessBuilder(command).start();
                //System.out.println("dibujo");
       
            } catch (Exception ex) {/*ignore*/}
        }
        
        
        
        
    }
    
    
    
}

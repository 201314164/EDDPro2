/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class columna {
    
    NodoMA cabeza;
    NodoMA fin;

    public columna() {
        
        this.cabeza = null;
        this.fin = null;
        
    }
    
    public NodoMA insertar(ruta newRut){
        
        return insertar(newRut, this.cabeza, this.fin);
        
    }
    
    private NodoMA insertar(ruta newRut, NodoMA hed,NodoMA teil){
        
        NodoMA nuevo = null;
        
        if (hed == null){
            
            nuevo = new NodoMA(newRut);
            cabeza = nuevo;
            fin = nuevo;
            
        }else{
            
            String id = newRut.getId();

            if(id.compareTo(hed.getRuta().getId()) < 0 || id.compareTo(hed.getRuta().getId()) == 0 ){
                
                if(id.compareTo(hed.getRuta().getId()) == 0){
                    //ya existe
                    
                }else{
                    //va antes de la cabeza
                    nuevo = new NodoMA(newRut);
                    nuevo.setAba(cabeza);
                    cabeza.setArr(nuevo);
                    cabeza = nuevo;
                
                }
                
            } else if(id.compareTo(teil.getRuta().getId()) > 0 || id.compareTo(teil.getRuta().getId()) == 0 ){
                
                if(id.compareTo(teil.getRuta().getId()) == 0){
                    //ya existe
                 
                }else{
                    //va despues del final
                    nuevo = new NodoMA(newRut);
                    fin.setAba(nuevo);
                    nuevo.setArr(fin);
                    fin = nuevo;
 
                }

            }else{
                
                NodoMA ante = hed;
                NodoMA curr = hed.getAba();
                while(curr != fin && id.compareTo(curr.getRuta().getId()) > 0){
                    ante = curr;
                    curr = curr.getAba();
               
                }
                
                if(id.compareTo(curr.getRuta().getId()) == 0){
                    //Ya existe  
                }else{
                    
                    nuevo = new NodoMA(newRut);
                    ante.setAba(nuevo);
                    nuevo.setArr(ante);
                    nuevo.setAba(curr);
                    curr.setArr(nuevo);
                    
   
                }
 
            }

        }
        
        return nuevo;
        
    }
    
    public void insertar(NodoMA nodo){
        
        insertar(nodo,this.cabeza,this.fin);
        
    }
    
    private void insertar(NodoMA nodo, NodoMA hed,NodoMA teil){
        
        if (hed == null){
            
            
            cabeza = nodo;
            fin = nodo;
            
        }else{
            
            String id = nodo.getRuta().getId();

            if(id.compareTo(hed.getRuta().getId()) < 0 || id.compareTo(hed.getRuta().getId()) == 0 ){
                
                if(id.compareTo(hed.getRuta().getId()) == 0){
                    //ya existe
                    
                }else{
                    //va antes de la cabeza
                    
                    nodo.setAba(cabeza);
                    cabeza.setArr(nodo);
                    cabeza = nodo;
                
                }
                
            } else if(id.compareTo(teil.getRuta().getId()) > 0 || id.compareTo(teil.getRuta().getId()) == 0 ){
                
                if(id.compareTo(teil.getRuta().getId()) == 0){
                    //ya existe
                 
                }else{
                    //va despues del final
                    
                    fin.setAba(nodo);
                    nodo.setArr(fin);
                    fin = nodo;
 
                }

            }else{
                
                NodoMA ante = hed;
                NodoMA curr = hed.getAba();
                while(curr != fin && id.compareTo(curr.getRuta().getId()) > 0){
                    ante = curr;
                    curr = curr.getAba();
               
                }
                
                if(id.compareTo(curr.getRuta().getId()) == 0){
                    //Ya existe  
                }else{
                    
                    
                    ante.setAba(nodo);
                    nodo.setArr(ante);
                    nodo.setAba(curr);
                    curr.setArr(nodo);
   
                }
 
            }

        }    
        
        
    }
    
    
        public boolean buscar(String cod){
        
        return buscar(cod, this.cabeza);
        
        
    }
    
    private boolean buscar(String dest, NodoMA hed){
        
        if (hed == null){
            return false;
        }else{
            
            NodoMA temp = hed;
            while(temp != null){
                if(temp.getRuta().getId().equals(dest)){
                    return true;
                }else{
                    temp = temp.getAba();
                }
                
                
                
            }
            
            
        }
        return false;
        
        
        
        
    }
    
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class listaAdy {
    
    NodoLady cabeza;
    NodoLady fin;

    public listaAdy() {
    
        this.cabeza = null;
        this.fin = null;
    
    }
    
    
    
    public void insertar(NodoAdy destino, int peso){
        
        insertar(destino, peso, this.cabeza,this.fin);
        
    }

    private void insertar(NodoAdy destino, int peso, NodoLady hed, NodoLady teil) {
        
        if (hed == null){
            
            NodoLady niu = new NodoLady(destino,peso);
            cabeza = niu;
            fin = niu;
            
        }else{
            
            if(teil != null){
                
                NodoLady niu = new NodoLady(destino,peso);
                fin.setSig(niu);
                fin = niu;
  
            }
 
        }
        
        
        
        
    }
    
    
    
    
    
}

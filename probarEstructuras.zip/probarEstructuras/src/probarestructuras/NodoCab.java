/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoCab {
    
    private destino destino;
    
    private columna columna;
    
    private NodoCab sig;
    

    public NodoCab() {
    
        this.destino = new destino();
        
        this.columna = new columna();
        
        this.sig = null;

    }

    public NodoCab(destino destino) {
        
        this.destino = destino;
        
        this.columna = new columna();
        
        this.sig = null;
        
        
    }

    /**
     * @return the destino
     */
    public destino getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(destino destino) {
        this.destino = destino;
    }

    /**
     * @return the sig
     */
    public NodoCab getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoCab sig) {
        this.sig = sig;
    }

    /**
     * @return the columna
     */
    public columna getColumna() {
        return columna;
    }

    /**
     * @param columna the columna to set
     */
    public void setColumna(columna columna) {
        this.columna = columna;
    }
    
    
    
    
    
    
    
    
}

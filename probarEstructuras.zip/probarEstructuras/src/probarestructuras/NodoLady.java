/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probarestructuras;

/**
 *
 * @author gios
 */
public class NodoLady {
    
    private NodoAdy destino;
    private int peso;
    private int tiempo;
    private int costo;
    
    private NodoLady sig;

    public NodoLady() {
    
        this.destino = new NodoAdy();
        this.peso = Integer.MAX_VALUE;
        this.tiempo = 0;
        this.costo = 0;
        
        this.sig = null;
    
    }

    public NodoLady(NodoAdy destino, int peso , ruta ruta) {
        this.destino = destino;
        this.peso = peso;
        this.tiempo = ruta.getTiempo();
        this.costo = ruta.getValor();
        this.sig = null;
    }
    
    public NodoLady(NodoAdy destino, int peso ) {
        this.destino = destino;
        this.peso = peso;
        
        this.sig = null;
    }

    /**
     * @return the destino
     */
    public NodoAdy getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(NodoAdy destino) {
        this.destino = destino;
    }

    /**
     * @return the peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(int peso) {
        this.peso = peso;
    }

    /**
     * @return the sig
     */
    public NodoLady getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(NodoLady sig) {
        this.sig = sig;
    }

    /**
     * @return the tiempo
     */
    public int getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    /**
     * @return the costo
     */
    public int getCosto() {
        return costo;
    }

    /**
     * @param costo the costo to set
     */
    public void setCosto(int costo) {
        this.costo = costo;
    }
    
    
    
    
    
    
    
}

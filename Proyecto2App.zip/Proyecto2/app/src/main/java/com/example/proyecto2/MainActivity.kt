package com.example.proyecto2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

import kotlinx.android.synthetic.main.activity_main.*;

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btnIng.setOnClickListener {

            if(passw.text.toString().isEmpty() || iden.text.toString().isEmpty()){

                Toast.makeText(this,"Uno o más campos se encuentran vacios", Toast.LENGTH_LONG).show()

            }else{

                val id = iden.text.toString()
                val pass = passw.text.toString()

                val queue = Volley.newRequestQueue(this)
                val url = "http://192.168.1.118:8080/Proyecto2/webresources/usuarios/logUsu/${id}/${pass}"

                val respuesta = StringRequest(Request.Method.GET, url,
                    Response.Listener<String> {response ->

                        if(response.toInt() == 1){

                            Toast.makeText(this,"Credenciales exitosas",Toast.LENGTH_LONG).show()
                            val intent1 = Intent(this,Inicio::class.java)
                            intent1.putExtra("usuario", iden.text.toString())
                            startActivity(intent1)


                        }else{

                            Toast.makeText(this,"Usuario o contraseña incorrecto",Toast.LENGTH_LONG).show()

                        }


                        //response -> Toast.makeText(this,"La respuesta es ${response}",Toast.LENGTH_LONG).show()
                    },
                    Response.ErrorListener {

                        Toast.makeText(this,"Ocurrio un error, intente nuevamente",Toast.LENGTH_LONG).show()

                    }


                    )

                queue.add(respuesta)

            }

        }


        btnNiu.setOnClickListener {

            val intent2 = Intent(this,niuUser::class.java)
            startActivity(intent2)


        }








    }
}

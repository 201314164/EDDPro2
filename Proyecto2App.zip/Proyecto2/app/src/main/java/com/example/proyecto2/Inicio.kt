package com.example.proyecto2

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_inicio.*

class Inicio : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio)

        val bundle = intent.extras
        val usu = bundle.getString("usuario")

        textView.text = "Bienvenido ${usu}!"


    }
}

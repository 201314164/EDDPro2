package com.example.proyecto2

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_niu_user.*
import org.json.JSONObject

class niuUser : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_niu_user)

        btnCrea.setOnClickListener {

        if(iden.text.toString().isEmpty() || nomb.text.toString().isEmpty() || passw.text.toString().isEmpty()){

            Toast.makeText(this,"Uno o más campos están vacios",Toast.LENGTH_LONG)

        }else{

            val niuUsu = JSONObject()
            niuUsu.put("id",iden.text.toString())
            niuUsu.put("pass",passw.text.toString())
            niuUsu.put("nombre",nomb.text.toString())

            val queue = Volley.newRequestQueue(this)
            val url = "http://192.168.1.118:8080/Proyecto2/webresources/usuarios"




            val respuesta = JsonObjectRequest(Request.Method.POST,url,niuUsu,
                Response.Listener<JSONObject> {response ->

                    Toast.makeText(this,"Usuario ${iden.text.toString()} creado, por favor inicie sesión",Toast.LENGTH_LONG).show()
                    finish()



                },
                Response.ErrorListener {

                    Toast.makeText(this,"Ocurrio un error, intente nuevamente",Toast.LENGTH_LONG).show()


                }



            )


            queue.add(respuesta)

        }





        btnCanc.setOnClickListener {

            finish()


        }







    }
}}
